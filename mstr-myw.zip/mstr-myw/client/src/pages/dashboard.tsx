import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import Terminal from "@/components/Terminal";
import PairingCode from "@/components/PairingCode";
import CommandCard from "@/components/CommandCard";
import StatusDisplay from "@/components/StatusDisplay";
import { Card, CardContent } from "@/components/ui/card";

interface Stats {
  totalCommands: number;
  activeGroups: number;
  eliteCount: number;
  challengesCompleted: number;
}

export default function Dashboard() {
  // Fetch initial data with fallback values
  const { data: botStatus } = useQuery<any>({
    queryKey: ['/api/bot/status'],
    refetchInterval: 10000
  });

  const { data: stats } = useQuery<Stats>({
    queryKey: ['/api/stats'],
    refetchInterval: 5000
  });

  const { data: logs } = useQuery({
    queryKey: ['/api/logs'],
    queryFn: () => fetch('/api/logs?limit=10').then(res => res.json()),
    refetchInterval: 3000
  });

  const currentStats: Stats = stats || {
    totalCommands: 300,
    activeGroups: 5,
    eliteCount: 12,
    challengesCompleted: 45
  };

  const currentLogs = logs || [
    { time: '10:39:32', level: 'info', message: '🐱 مستر مياو يبدأ رحلته الأسطورية...' },
    { time: '10:39:32', level: 'info', message: '🔌 جاري الاتصال بواتساب...' },
    { time: '10:39:32', level: 'info', message: 'serving on port 5000' }
  ];
  const currentSession = botStatus?.session || null;

  return (
    <div className="min-h-screen bg-terminal-dark text-white matrix-bg">
      {/* Matrix Rain Background Effect */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {['م', 'ي', 'ا', 'و', '🐱', '⚡', '🎌', '💫', '🔥', '⭐'].map((char, i) => (
          <div
            key={i}
            className="matrix-char"
            style={{
              left: `${(i + 1) * 10}%`,
              animationDelay: `${i * 0.5}s`
            }}
          >
            {char}
          </div>
        ))}
      </div>

      <div className="relative z-10">
        {/* Header with ASCII Art Logo */}
        <header className="p-6">
          <div className="terminal-border bg-terminal-navy p-6 mx-auto max-w-6xl">
            <div className="text-center">
              <div className="ascii-art text-anime-gold text-xs md:text-sm glow-animation mb-4 font-mono">
                {`███╗   ███╗██████╗     ███╗   ███╗██╗ █████╗ ██╗    ██╗
████╗ ████║██╔══██╗    ████╗ ████║██║██╔══██╗██║    ██║
██╔████╔██║██████╔╝    ██╔████╔██║██║███████║██║ █╗ ██║
██║╚██╔╝██║██╔══██╗    ██║╚██╔╝██║██║██╔══██║██║███╗██║
██║ ╚═╝ ██║██║  ██║    ██║ ╚═╝ ██║██║██║  ██║╚███╔███╔╝
╚═╝     ╚═╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚═╝╚═╝  ╚═╝ ╚══╝╚══╝`}
              </div>
              <h1 className="text-3xl md:text-5xl font-bold text-anime-gold glow-text mb-2">مستر مياو</h1>
              <p className="text-anime-blue text-lg">بوت واتساب أسطوري بطعم الأنمي والكوميديا المصرية 🐱⚡</p>
              
              <StatusDisplay 
                session={currentSession}
                stats={currentStats}
              />
            </div>
          </div>
        </header>

        {/* Main Dashboard */}
        <main className="container mx-auto px-6 pb-12">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-anime-gold mb-2">
                  👑
                </div>
                <div className="text-2xl font-mono text-anime-gold" data-testid="elite-count">
                  {currentStats.eliteCount}
                </div>
                <div className="text-sm text-gray-400">أدمن نشط</div>
              </CardContent>
            </Card>
            
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-anime-blue mb-2">
                  🔥
                </div>
                <div className="text-2xl font-mono text-anime-blue" data-testid="commands-count">
                  {currentStats.totalCommands}
                </div>
                <div className="text-sm text-gray-400">أمر منفذ اليوم</div>
              </CardContent>
            </Card>
            
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-anime-pink mb-2">
                  🎮
                </div>
                <div className="text-2xl font-mono text-anime-pink" data-testid="challenges-count">
                  {currentStats.challengesCompleted}
                </div>
                <div className="text-sm text-gray-400">تحدي نشط</div>
              </CardContent>
            </Card>
            
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-anime-green mb-2">
                  ⭐
                </div>
                <div className="text-2xl font-mono text-anime-green" data-testid="groups-count">
                  {currentStats.activeGroups}
                </div>
                <div className="text-sm text-gray-400">مجموعة نشطة</div>
              </CardContent>
            </Card>
          </div>

          {/* Terminal Interface */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <Terminal logs={currentLogs} />
            <PairingCode session={currentSession} />
          </div>

          {/* Commands Dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Admin Commands */}
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-anime-gold mb-4 flex items-center gap-2">
                  👑 أوامر الأدمن
                </h3>
                
                <div className="space-y-3">
                  <CommandCard
                    command=".طرد"
                    description="طرد عضو من المجموعة"
                    icon="🚫"
                    color="text-red-400"
                  />
                  <CommandCard
                    command=".ترحيب"
                    description="تعديل رسالة الترحيب"
                    icon="👋"
                    color="text-anime-green"
                  />
                  <CommandCard
                    command=".كتم"
                    description="كتم عضو مؤقتاً"
                    icon="🔇"
                    color="text-yellow-400"
                  />
                  <CommandCard
                    command=".تنظيف"
                    description="حذف رسائل متعددة"
                    icon="🧹"
                    color="text-anime-blue"
                  />
                  <CommandCard
                    command=".نخبة"
                    description="إدارة أرقام النخبة"
                    icon="⭐"
                    color="text-anime-pink"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Anime Commands */}
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-anime-pink mb-4 flex items-center gap-2">
                  🚀 أوامر الأنمي
                </h3>
                
                <div className="space-y-3">
                  <CommandCard
                    command=".انمي"
                    description="بحث عن أنمي معين"
                    icon="▶️"
                    color="text-anime-pink"
                  />
                  <CommandCard
                    command=".وايفو"
                    description="صور شخصيات الوايفو"
                    icon="💖"
                    color="text-red-400"
                  />
                  <CommandCard
                    command=".مانجا"
                    description="بحث في المانجا"
                    icon="📚"
                    color="text-anime-blue"
                  />
                  <CommandCard
                    command=".اقتباس_انمي"
                    description="اقتباسات من الأنمي"
                    icon="💬"
                    color="text-anime-gold"
                  />
                  <CommandCard
                    command=".كاواي"
                    description="صور كاواي ولطيفة"
                    icon="🐱"
                    color="text-anime-pink"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Challenge System */}
            <Card className="terminal-border bg-terminal-navy">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-anime-green mb-4 flex items-center gap-2">
                  🎮 التحديات والألعاب
                </h3>
                
                <div className="space-y-3">
                  <CommandCard
                    command=".تحدي_عين"
                    description="تحدي تخمين لون العين"
                    icon="👁️"
                    color="text-anime-blue"
                  />
                  <CommandCard
                    command=".تحدي_شخصية"
                    description="تخمين شخصية الأنمي"
                    icon="🎭"
                    color="text-anime-pink"
                  />
                  <CommandCard
                    command=".احجية"
                    description="أحاجي وألغاز"
                    icon="🧩"
                    color="text-yellow-400"
                  />
                  <CommandCard
                    command=".مسابقة"
                    description="مسابقات جماعية"
                    icon="🏆"
                    color="text-anime-gold"
                  />
                  <CommandCard
                    command=".حظ"
                    description="ألعاب الحظ والتوقعات"
                    icon="🎲"
                    color="text-anime-pink"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
