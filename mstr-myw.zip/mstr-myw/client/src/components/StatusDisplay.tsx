import { Badge } from "@/components/ui/badge";
import { Users, Zap, Crown } from "lucide-react";

interface StatusDisplayProps {
  session: any;
  stats: {
    totalCommands: number;
    activeGroups: number;
    eliteCount: number;
    challengesCompleted: number;
  };
}

export default function StatusDisplay({ session, stats }: StatusDisplayProps) {
  const getConnectionStatus = () => {
    if (!session) {
      return {
        text: 'غير متصل',
        color: 'bg-red-500',
        pulse: false
      };
    }

    switch (session.status) {
      case 'connected':
        return {
          text: 'متصل',
          color: 'bg-anime-green',
          pulse: true
        };
      case 'connecting':
        return {
          text: 'جاري الاتصال',
          color: 'bg-anime-blue',
          pulse: true
        };
      case 'pairing':
        return {
          text: 'في انتظار الربط',
          color: 'bg-anime-gold',
          pulse: true
        };
      default:
        return {
          text: 'غير متصل',
          color: 'bg-red-500',
          pulse: false
        };
    }
  };

  const connectionStatus = getConnectionStatus();

  return (
    <div className="flex items-center justify-center gap-4 mt-6 flex-wrap">
      {/* Connection Status */}
      <div className="flex items-center gap-2">
        <div 
          className={`w-3 h-3 rounded-full ${connectionStatus.color} ${connectionStatus.pulse ? 'status-online' : ''}`}
          data-testid="status-indicator"
        ></div>
        <span className="text-anime-green font-mono" data-testid="status-text">
          {connectionStatus.text}
        </span>
      </div>

      <div className="text-gray-400 hidden sm:block">|</div>

      {/* Active Groups */}
      <div className="flex items-center gap-2">
        <Users className="w-4 h-4 text-anime-blue" />
        <span className="text-anime-blue" data-testid="active-groups">
          {stats.activeGroups} مجموعة نشطة
        </span>
      </div>

      <div className="text-gray-400 hidden sm:block">|</div>

      {/* Commands Ready */}
      <div className="flex items-center gap-2">
        <Zap className="w-4 h-4 text-anime-gold" />
        <span className="text-anime-gold" data-testid="commands-ready">
          300 أمر جاهز
        </span>
      </div>

      <div className="text-gray-400 hidden lg:block">|</div>

      {/* Elite Members */}
      <div className="flex items-center gap-2">
        <Crown className="w-4 h-4 text-anime-pink" />
        <span className="text-anime-pink" data-testid="elite-members">
          {stats.eliteCount} عضو نخبة
        </span>
      </div>

      {/* Live Indicator */}
      <div className="flex items-center gap-2 mt-2 sm:mt-0">
        <Badge 
          variant="outline" 
          className="bg-anime-green/10 border-anime-green text-anime-green animate-pulse"
          data-testid="live-indicator"
        >
          🔴 LIVE
        </Badge>
      </div>
    </div>
  );
}
