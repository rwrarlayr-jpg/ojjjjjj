import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useRef } from "react";

interface TerminalProps {
  logs: any[];
}

export default function Terminal({ logs }: TerminalProps) {
  const terminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs]);

  const formatLogMessage = (log: any) => {
    const timestamp = new Date(log.timestamp).toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    if (log.command) {
      return {
        type: 'command',
        text: `[${timestamp}] [MSG] ${log.sender}: ${log.command}`,
        color: 'text-white'
      };
    }

    return {
      type: 'info',
      text: `[${timestamp}] [INFO] ${log.response || 'تم تنفيذ الأمر'}`,
      color: 'text-anime-blue'
    };
  };

  const sampleLogs = [
    { type: 'success', text: '[✓] تم تحميل 300 أمر بنجاح', color: 'text-anime-green' },
    { type: 'info', text: '[INFO] البوت جاهز للاستقبال', color: 'text-anime-blue' },
    { type: 'elite', text: '[ELITE] تم إضافة رقم جديد للنخبة', color: 'text-anime-gold' },
    ...logs.map(formatLogMessage)
  ];

  return (
    <Card className="terminal-border bg-terminal-navy">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4 border-b border-gray-700 pb-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
          <div className="w-3 h-3 bg-anime-green rounded-full"></div>
          <span className="text-anime-gold font-mono mr-4">Terminal - مستر مياو</span>
        </div>
        
        <div 
          ref={terminalRef}
          className="font-mono text-sm space-y-2 h-80 overflow-y-auto"
          data-testid="terminal-logs"
        >
          {sampleLogs.map((log, index) => (
            <div key={index} className={log.color}>
              {log.text}
            </div>
          ))}
        </div>
        
        <div className="mt-4 flex items-center">
          <span className="text-anime-gold mr-2">$</span>
          <input 
            type="text" 
            className="bg-transparent border-none outline-none text-white font-mono flex-1" 
            placeholder="اكتب أمر..."
            data-testid="terminal-input"
          />
          <div className="w-2 h-4 bg-anime-gold animate-pulse"></div>
        </div>
      </CardContent>
    </Card>
  );
}
