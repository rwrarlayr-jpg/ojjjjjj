import { Card } from "@/components/ui/card";

interface CommandCardProps {
  command: string;
  description: string;
  icon: string;
  color: string;
}

export default function CommandCard({ command, description, icon, color }: CommandCardProps) {
  return (
    <Card className="command-card bg-gray-800 p-3 rounded-lg transition-all duration-200 hover:bg-gray-700 cursor-pointer group" data-testid={`command-${command.replace('.', '')}`}>
      <div className="flex items-center justify-between">
        <span className={`font-mono text-anime-gold group-hover:text-anime-blue transition-colors`}>
          {command}
        </span>
        <span className={`text-lg ${color} group-hover:scale-110 transition-transform`}>
          {icon}
        </span>
      </div>
      <p className="text-sm text-gray-400 mt-1 group-hover:text-gray-300 transition-colors">
        {description}
      </p>
    </Card>
  );
}
