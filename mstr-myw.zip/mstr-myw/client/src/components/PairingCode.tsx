import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Copy, RefreshCw, Smartphone } from "lucide-react";

interface PairingCodeProps {
  session: any;
}

export default function PairingCode({ session }: PairingCodeProps) {
  const [phoneNumber, setPhoneNumber] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const pairMutation = useMutation({
    mutationFn: async (phone: string) => {
      const res = await apiRequest("POST", "/api/bot/pair", { phoneNumber: phone });
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "✅ تم إنشاء كود الربط!",
        description: `كود الربط: ${data.pairingCode}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
    },
    onError: (error) => {
      toast({
        title: "❌ فشل في إنشاء كود الربط",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePairRequest = () => {
    if (!phoneNumber.trim()) {
      toast({
        title: "⚠️ رقم الهاتف مطلوب",
        description: "من فضلك أدخل رقم هاتفك",
        variant: "destructive",
      });
      return;
    }

    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (cleanNumber.length < 10 || cleanNumber.length > 15) {
      toast({
        title: "⚠️ رقم هاتف غير صحيح",
        description: "تأكد من صحة رقم الهاتف",
        variant: "destructive",
      });
      return;
    }

    pairMutation.mutate(cleanNumber);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "✅ تم النسخ!",
        description: "تم نسخ الكود إلى الحافظة",
      });
    } catch (error) {
      toast({
        title: "❌ فشل في النسخ",
        description: "لم نتمكن من نسخ الكود",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'text-anime-green';
      case 'pairing':
        return 'text-anime-gold';
      case 'connecting':
        return 'text-anime-blue';
      default:
        return 'text-red-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'connected':
        return 'متصل';
      case 'pairing':
        return 'في انتظار الربط';
      case 'connecting':
        return 'جاري الاتصال';
      default:
        return 'غير متصل';
    }
  };

  return (
    <Card className="terminal-border bg-terminal-navy">
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-anime-gold mb-4 flex items-center gap-2">
          <Smartphone className="w-5 h-5" />
          كود الربط
        </h3>
        
        <div className="text-center space-y-4">
          {/* Anime character avatar */}
          <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-anime-pink to-anime-blue flex items-center justify-center text-4xl">
            🐱
          </div>
          
          {session?.pairingCode ? (
            <>
              <div className="bg-black p-4 rounded-lg border border-anime-gold">
                <div className="text-2xl font-mono text-anime-gold text-center glow-text" data-testid="pairing-code">
                  {session.pairingCode}
                </div>
              </div>
              
              <div className="text-sm text-gray-400 space-y-1">
                <p data-testid="phone-number">رقم الهاتف: {session.phoneNumber}</p>
                <p>الحالة: <span className={getStatusColor(session.status)} data-testid="connection-status">
                  {getStatusText(session.status)}
                </span></p>
                <p>انتهاء الصلاحية: 5 دقائق</p>
              </div>
              
              <div className="flex justify-center gap-2">
                <Button
                  onClick={() => copyToClipboard(session.pairingCode)}
                  className="bg-anime-blue hover:bg-blue-600"
                  data-testid="button-copy-code"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  نسخ الكود
                </Button>
                <Button
                  onClick={() => pairMutation.mutate(session.phoneNumber)}
                  disabled={pairMutation.isPending}
                  className="bg-anime-green hover:bg-green-600"
                  data-testid="button-refresh-code"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${pairMutation.isPending ? 'animate-spin' : ''}`} />
                  تجديد
                </Button>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-4">
                <p className="text-anime-blue">أدخل رقم هاتفك للحصول على كود الربط</p>
                
                <div className="space-y-2">
                  <Input
                    type="tel"
                    placeholder="مثال: +201234567890"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="bg-black border-anime-gold text-white text-center"
                    dir="ltr"
                    data-testid="input-phone-number"
                  />
                  
                  <Button
                    onClick={handlePairRequest}
                    disabled={pairMutation.isPending}
                    className="w-full bg-anime-gold hover:bg-yellow-600 text-black font-bold"
                    data-testid="button-generate-code"
                  >
                    {pairMutation.isPending ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        جاري الإنشاء...
                      </>
                    ) : (
                      <>
                        <Smartphone className="w-4 h-4 mr-2" />
                        إنشاء كود الربط
                      </>
                    )}
                  </Button>
                </div>
              </div>
              
              <div className="text-xs text-gray-500 mt-4 space-y-1">
                <p>🔒 آمن ومشفر</p>
                <p>⏰ صالح لمدة 5 دقائق</p>
                <p>📱 أدخل الكود في واتساب</p>
              </div>
            </>
          )}
          
          {/* Connection tips */}
          <div className="text-xs text-gray-400 bg-gray-800 p-3 rounded-lg mt-4">
            <h4 className="text-anime-gold font-bold mb-2">💡 نصائح الربط:</h4>
            <ul className="text-right space-y-1">
              <li>• تأكد من اتصالك بالإنترنت</li>
              <li>• افتح واتساب وانتظر تحميل المحادثات</li>
              <li>• اذهب لإعدادات → الأجهزة المرتبطة</li>
              <li>• اختر "ربط جهاز" وأدخل الكود</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
