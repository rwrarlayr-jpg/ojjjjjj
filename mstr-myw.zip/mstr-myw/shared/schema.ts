import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const botSessions = pgTable("bot_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: text("phone_number").notNull(),
  pairingCode: text("pairing_code"),
  status: text("status").notNull().default("disconnected"), // connected, disconnected, pairing
  createdAt: timestamp("created_at").defaultNow(),
  lastConnected: timestamp("last_connected"),
});

export const commandLogs = pgTable("command_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  command: text("command").notNull(),
  sender: text("sender").notNull(),
  groupId: text("group_id"),
  response: text("response"),
  timestamp: timestamp("timestamp").defaultNow(),
  executionTime: integer("execution_time"), // in milliseconds
});

export const eliteNumbers = pgTable("elite_numbers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: text("phone_number").notNull().unique(),
  addedBy: text("added_by"),
  addedAt: timestamp("added_at").defaultNow(),
});

export const groupSettings = pgTable("group_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: text("group_id").notNull().unique(),
  welcomeMessage: text("welcome_message"),
  adminOnly: boolean("admin_only").default(false),
  antiSpam: boolean("anti_spam").default(true),
  settings: jsonb("settings").default({}),
});

export const challenges = pgTable("challenges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // eye, character, riddle, etc.
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  imageUrl: text("image_url"),
  difficulty: text("difficulty").default("medium"),
  points: integer("points").default(10),
  isActive: boolean("is_active").default(true),
});

export const userPoints = pgTable("user_points", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: text("phone_number").notNull().unique(),
  points: integer("points").default(0),
  rank: text("rank").default("مبتدئ"),
  challengesCompleted: integer("challenges_completed").default(0),
  lastActive: timestamp("last_active").defaultNow(),
});

export const adminCodes = pgTable("admin_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(),
  usedBy: text("used_by"),
  usedAt: timestamp("used_at"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBotSessionSchema = createInsertSchema(botSessions).pick({
  phoneNumber: true,
  pairingCode: true,
  status: true,
});

export const insertCommandLogSchema = createInsertSchema(commandLogs).pick({
  command: true,
  sender: true,
  groupId: true,
  response: true,
  executionTime: true,
});

export const insertEliteNumberSchema = createInsertSchema(eliteNumbers).pick({
  phoneNumber: true,
  addedBy: true,
});

export const insertGroupSettingsSchema = createInsertSchema(groupSettings).pick({
  groupId: true,
  welcomeMessage: true,
  adminOnly: true,
  antiSpam: true,
  settings: true,
});

export const insertChallengeSchema = createInsertSchema(challenges).pick({
  type: true,
  question: true,
  answer: true,
  imageUrl: true,
  difficulty: true,
  points: true,
});

export const insertUserPointsSchema = createInsertSchema(userPoints).pick({
  phoneNumber: true,
  points: true,
  rank: true,
  challengesCompleted: true,
});

export const insertAdminCodeSchema = createInsertSchema(adminCodes).pick({
  code: true,
  usedBy: true,
  isActive: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type BotSession = typeof botSessions.$inferSelect;
export type CommandLog = typeof commandLogs.$inferSelect;
export type EliteNumber = typeof eliteNumbers.$inferSelect;
export type GroupSettings = typeof groupSettings.$inferSelect;
export type Challenge = typeof challenges.$inferSelect;
export type UserPoints = typeof userPoints.$inferSelect;
export type AdminCode = typeof adminCodes.$inferSelect;
