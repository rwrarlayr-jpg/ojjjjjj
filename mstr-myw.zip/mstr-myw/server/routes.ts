import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { z } from "zod";
import { bot } from "./whatsapp/bot";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Note: WebSocket temporarily disabled to prevent conflicts with Vite HMR
  // Real-time updates will be handled via polling for now

  // Bot session endpoints
  app.get("/api/bot/status", async (req, res) => {
    try {
      const session = await storage.getBotSession();
      const stats = await storage.getStats();
      
      res.json({
        session,
        stats,
        isConnected: session?.status === 'connected'
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get bot status" });
    }
  });

  app.post("/api/bot/pair", async (req, res) => {
    try {
      const { phoneNumber } = z.object({
        phoneNumber: z.string().min(10)
      }).parse(req.body);

      const pairingCode = await bot.requestPairingCode(phoneNumber);
      
      let session = await storage.getBotSession();
      if (session) {
        session = await storage.updateBotSession(session.id, {
          phoneNumber,
          pairingCode,
          status: 'pairing'
        });
      } else {
        session = await storage.createBotSession({
          phoneNumber,
          pairingCode,
          status: 'pairing'
        });
      }

      res.json({ pairingCode, session });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate pairing code" });
    }
  });

  // Command logs endpoints
  app.get("/api/logs", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const logs = await storage.getCommandLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get command logs" });
    }
  });

  // Elite numbers endpoints
  app.get("/api/elite", async (req, res) => {
    try {
      const eliteNumbers = await storage.getEliteNumbers();
      res.json(eliteNumbers);
    } catch (error) {
      res.status(500).json({ message: "Failed to get elite numbers" });
    }
  });

  app.post("/api/elite", async (req, res) => {
    try {
      const { phoneNumber, addedBy } = z.object({
        phoneNumber: z.string(),
        addedBy: z.string().optional()
      }).parse(req.body);

      const eliteNumber = await storage.addEliteNumber(phoneNumber, addedBy);
      res.json(eliteNumber);
    } catch (error) {
      res.status(500).json({ message: "Failed to add elite number" });
    }
  });

  app.delete("/api/elite/:phoneNumber", async (req, res) => {
    try {
      const { phoneNumber } = req.params;
      const removed = await storage.removeEliteNumber(phoneNumber);
      
      if (removed) {
        res.json({ message: "Elite number removed successfully" });
      } else {
        res.status(404).json({ message: "Elite number not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to remove elite number" });
    }
  });

  // Challenges endpoints
  app.get("/api/challenges", async (req, res) => {
    try {
      const type = req.query.type as string;
      const challenges = await storage.getChallenges(type);
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: "Failed to get challenges" });
    }
  });

  app.get("/api/challenges/random/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const challenge = await storage.getRandomChallenge(type);
      
      if (challenge) {
        res.json(challenge);
      } else {
        res.status(404).json({ message: "No challenges found for this type" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to get random challenge" });
    }
  });

  // Statistics endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get statistics" });
    }
  });

  return httpServer;
}
