import { 
  type User, 
  type InsertUser,
  type BotSession,
  type CommandLog,
  type EliteNumber,
  type GroupSettings,
  type Challenge,
  type UserPoints,
  type AdminCode
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bot Sessions
  getBotSession(): Promise<BotSession | undefined>;
  createBotSession(session: Partial<BotSession>): Promise<BotSession>;
  updateBotSession(id: string, updates: Partial<BotSession>): Promise<BotSession | undefined>;
  
  // Command Logs
  getCommandLogs(limit?: number): Promise<CommandLog[]>;
  createCommandLog(log: Omit<CommandLog, 'id' | 'timestamp'>): Promise<CommandLog>;
  
  // Elite Numbers
  getEliteNumbers(): Promise<EliteNumber[]>;
  addEliteNumber(phoneNumber: string, addedBy?: string): Promise<EliteNumber>;
  removeEliteNumber(phoneNumber: string): Promise<boolean>;
  isEliteNumber(phoneNumber: string): Promise<boolean>;
  
  // Group Settings
  getGroupSettings(groupId: string): Promise<GroupSettings | undefined>;
  updateGroupSettings(groupId: string, settings: Partial<GroupSettings>): Promise<GroupSettings>;
  
  // Challenges
  getChallenges(type?: string): Promise<Challenge[]>;
  getRandomChallenge(type: string): Promise<Challenge | undefined>;
  createChallenge(challenge: Omit<Challenge, 'id'>): Promise<Challenge>;
  
  // Stats
  getStats(): Promise<{
    totalCommands: number;
    activeGroups: number;
    eliteCount: number;
    challengesCompleted: number;
  }>;
  
  // User Points
  getUserPoints(phoneNumber: string): Promise<UserPoints | undefined>;
  updateUserPoints(phoneNumber: string, points: number, challengesCompleted?: number): Promise<UserPoints>;
  getTopUsers(limit?: number): Promise<UserPoints[]>;
  
  // Admin Codes
  createAdminCode(code: string): Promise<AdminCode>;
  validateAdminCode(code: string, phoneNumber: string): Promise<boolean>;
  getAdminCodes(): Promise<AdminCode[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private botSessions: Map<string, BotSession>;
  private commandLogs: CommandLog[];
  private eliteNumbers: Map<string, EliteNumber>;
  private groupSettings: Map<string, GroupSettings>;
  private challenges: Map<string, Challenge>;
  private userPoints: Map<string, UserPoints>;
  private adminCodes: Map<string, AdminCode>;

  constructor() {
    this.users = new Map();
    this.botSessions = new Map();
    this.commandLogs = [];
    this.eliteNumbers = new Map();
    this.groupSettings = new Map();
    this.challenges = new Map();
    this.userPoints = new Map();
    this.adminCodes = new Map();
    
    // Initialize with sample challenges and admin codes
    this.initializeChallenges();
    this.initializeAdminCodes();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getBotSession(): Promise<BotSession | undefined> {
    return Array.from(this.botSessions.values())[0];
  }

  async createBotSession(session: Partial<BotSession>): Promise<BotSession> {
    const id = randomUUID();
    const botSession: BotSession = {
      id,
      phoneNumber: session.phoneNumber || "",
      pairingCode: session.pairingCode || null,
      status: session.status || "disconnected",
      createdAt: new Date(),
      lastConnected: session.lastConnected || null,
    };
    this.botSessions.set(id, botSession);
    return botSession;
  }

  async updateBotSession(id: string, updates: Partial<BotSession>): Promise<BotSession | undefined> {
    const session = this.botSessions.get(id);
    if (!session) return undefined;
    
    const updated = { ...session, ...updates };
    this.botSessions.set(id, updated);
    return updated;
  }

  async getCommandLogs(limit = 50): Promise<CommandLog[]> {
    return this.commandLogs
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }

  async createCommandLog(log: Omit<CommandLog, 'id' | 'timestamp'>): Promise<CommandLog> {
    const id = randomUUID();
    const commandLog: CommandLog = {
      id,
      ...log,
      timestamp: new Date(),
    };
    this.commandLogs.push(commandLog);
    
    // Keep only last 1000 logs
    if (this.commandLogs.length > 1000) {
      this.commandLogs = this.commandLogs.slice(-1000);
    }
    
    return commandLog;
  }

  async getEliteNumbers(): Promise<EliteNumber[]> {
    return Array.from(this.eliteNumbers.values());
  }

  async addEliteNumber(phoneNumber: string, addedBy?: string): Promise<EliteNumber> {
    const id = randomUUID();
    const eliteNumber: EliteNumber = {
      id,
      phoneNumber,
      addedBy: addedBy || null,
      addedAt: new Date(),
    };
    this.eliteNumbers.set(phoneNumber, eliteNumber);
    return eliteNumber;
  }

  async removeEliteNumber(phoneNumber: string): Promise<boolean> {
    return this.eliteNumbers.delete(phoneNumber);
  }

  async isEliteNumber(phoneNumber: string): Promise<boolean> {
    return this.eliteNumbers.has(phoneNumber);
  }

  async getGroupSettings(groupId: string): Promise<GroupSettings | undefined> {
    return this.groupSettings.get(groupId);
  }

  async updateGroupSettings(groupId: string, settings: Partial<GroupSettings>): Promise<GroupSettings> {
    const existing = this.groupSettings.get(groupId);
    const id = existing?.id || randomUUID();
    
    const groupSetting: GroupSettings = {
      id,
      groupId,
      welcomeMessage: settings.welcomeMessage || existing?.welcomeMessage || null,
      adminOnly: settings.adminOnly ?? existing?.adminOnly ?? false,
      antiSpam: settings.antiSpam ?? existing?.antiSpam ?? true,
      settings: settings.settings || existing?.settings || {},
    };
    
    this.groupSettings.set(groupId, groupSetting);
    return groupSetting;
  }

  async getChallenges(type?: string): Promise<Challenge[]> {
    const challenges = Array.from(this.challenges.values());
    return type ? challenges.filter(c => c.type === type && c.isActive) : challenges;
  }

  async getRandomChallenge(type: string): Promise<Challenge | undefined> {
    const challenges = await this.getChallenges(type);
    if (challenges.length === 0) return undefined;
    return challenges[Math.floor(Math.random() * challenges.length)];
  }

  async createChallenge(challenge: Omit<Challenge, 'id'>): Promise<Challenge> {
    const id = randomUUID();
    const newChallenge: Challenge = { id, ...challenge };
    this.challenges.set(id, newChallenge);
    return newChallenge;
  }

  async getStats(): Promise<{
    totalCommands: number;
    activeGroups: number;
    eliteCount: number;
    challengesCompleted: number;
  }> {
    return {
      totalCommands: this.commandLogs.length,
      activeGroups: this.groupSettings.size,
      eliteCount: this.eliteNumbers.size,
      challengesCompleted: this.commandLogs.filter(log => log.command.includes('تحدي')).length,
    };
  }

  async getUserPoints(phoneNumber: string): Promise<UserPoints | undefined> {
    return this.userPoints.get(phoneNumber);
  }

  async updateUserPoints(phoneNumber: string, points: number, challengesCompleted = 0): Promise<UserPoints> {
    const existing = this.userPoints.get(phoneNumber);
    const totalPoints = (existing?.points || 0) + points;
    const totalChallenges = (existing?.challengesCompleted || 0) + challengesCompleted;
    
    const rank = this.calculateRank(totalPoints);
    
    const userPoints: UserPoints = {
      id: existing?.id || randomUUID(),
      phoneNumber,
      points: totalPoints,
      rank,
      challengesCompleted: totalChallenges,
      lastActive: new Date(),
    };
    
    this.userPoints.set(phoneNumber, userPoints);
    return userPoints;
  }

  async getTopUsers(limit = 10): Promise<UserPoints[]> {
    return Array.from(this.userPoints.values())
      .sort((a, b) => (b.points || 0) - (a.points || 0))
      .slice(0, limit);
  }

  async createAdminCode(code: string): Promise<AdminCode> {
    const id = randomUUID();
    const adminCode: AdminCode = {
      id,
      code,
      usedBy: null,
      usedAt: null,
      isActive: true,
      createdAt: new Date(),
    };
    this.adminCodes.set(code, adminCode);
    return adminCode;
  }

  async validateAdminCode(code: string, phoneNumber: string): Promise<boolean> {
    const adminCode = this.adminCodes.get(code);
    if (!adminCode || !adminCode.isActive || adminCode.usedBy) {
      return false;
    }
    
    adminCode.usedBy = phoneNumber;
    adminCode.usedAt = new Date();
    adminCode.isActive = false;
    this.adminCodes.set(code, adminCode);
    
    await this.addEliteNumber(phoneNumber, 'admin-code');
    return true;
  }

  async getAdminCodes(): Promise<AdminCode[]> {
    return Array.from(this.adminCodes.values());
  }

  private calculateRank(points: number): string {
    if (points >= 1000) return '🏆 أسطوري';
    if (points >= 500) return '💎 ماسي';
    if (points >= 250) return '⭐ ذهبي';
    if (points >= 100) return '🥈 فضي';
    if (points >= 50) return '🥉 برونزي';
    return '🌟 مبتدئ';
  }

  private initializeChallenges() {
    const sampleChallenges = [
      {
        type: 'eye',
        question: 'ما لون العين في هذه الصورة؟',
        answer: 'أزرق',
        imageUrl: 'https://example.com/eye1.jpg',
        difficulty: 'easy',
        points: 10,
        isActive: true
      },
      {
        type: 'eye',
        question: 'ما لون العين في هذه الصورة؟',
        answer: 'أخضر',
        imageUrl: 'https://example.com/eye2.jpg',
        difficulty: 'medium',
        points: 20,
        isActive: true
      },
      {
        type: 'eye',
        question: 'ما لون العين في هذه الصورة؟',
        answer: 'بني',
        imageUrl: 'https://example.com/eye3.jpg',
        difficulty: 'hard',
        points: 30,
        isActive: true
      },
      {
        type: 'character',
        question: 'من هذه الشخصية من أنمي ناروتو؟',
        answer: 'ساسكي',
        imageUrl: 'https://example.com/sasuke.jpg',
        difficulty: 'medium',
        points: 20,
        isActive: true
      },
      {
        type: 'riddle',
        question: 'شيء له عينان ولا يرى، ما هو؟',
        answer: 'المقص',
        imageUrl: null,
        difficulty: 'medium',
        points: 15,
        isActive: true
      }
    ];

    sampleChallenges.forEach(challenge => {
      const id = randomUUID();
      this.challenges.set(id, { id, ...challenge });
    });
  }

  private initializeAdminCodes() {
    const defaultCode = 'MRMEOW2025';
    this.createAdminCode(defaultCode);
  }
}

export const storage = new MemStorage();
