import { makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers } from '@whiskeysockets/baileys';
import fs from 'fs-extra';
import pino from 'pino';
import path from 'path';
import chalk from 'chalk';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { logger } from './utils/logger';
import { handleMessage } from './handlers/messageHandler';
import { storage } from '../storage';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class WhatsAppBot {
  private sock: any = null;
  private isConnected = false;

  constructor() {
    this.startBot();
  }

  async startBot() {
    try {
      logger.info('🐱 مستر مياو يبدأ رحلته الأسطورية...');
      
      const sessionDir = path.join(__dirname, '../../session');
      await fs.ensureDir(sessionDir);

      const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

      this.sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        browser: Browsers.ubuntu('Chrome'),
        logger: pino({ level: 'silent' }),
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true
      });

      this.sock.ev.on('connection.update', async (update: any) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'connecting') {
          logger.info('🔌 جاري الاتصال بواتساب...');
          await this.updateBotStatus('connecting');
        }

        if (connection === 'open') {
          logger.success(`🎉 مستر مياو متصل! USER ID: ${this.sock.user.id}`);
          this.isConnected = true;
          
          await this.updateBotStatus('connected');
          
          // Add bot number to elite automatically
          try {
            const botNumber = this.sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            await storage.addEliteNumber(botNumber, 'system');
            logger.info(`⭐ تم إضافة رقم البوت ${botNumber} للنخبة تلقائياً`);
          } catch (e) {
            logger.error('فشل في إضافة رقم البوت للنخبة:', e);
          }
        }

        if (connection === 'close') {
          const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          logger.warn(`💔 انقطع الاتصال: ${lastDisconnect?.error?.message || 'سبب غير معروف'}`);
          
          this.isConnected = false;
          await this.updateBotStatus('disconnected');

          if (isLoggedOut) {
            logger.error('🚪 تم تسجيل الخروج من الحساب - يرجى طلب كود ربط جديد من لوحة التحكم');
            // Don't exit the process, just stay disconnected
            // User can request a new pairing code from the dashboard
          } else if (statusCode === DisconnectReason.connectionClosed || 
                     statusCode === DisconnectReason.connectionLost ||
                     statusCode === DisconnectReason.connectionReplaced) {
            logger.info('🔄 محاولة إعادة الاتصال...');
            setTimeout(() => this.startBot(), 3000);
          } else {
            logger.warn('⏸️ البوت في وضع الانتظار - استخدم لوحة التحكم للاتصال');
          }
        }
      });

      this.sock.ev.on('messages.upsert', async (m: any) => {
        try {
          await handleMessage(this.sock, m, storage);
        } catch (err) {
          logger.error('خطأ في معالجة الرسالة:', err);
        }
      });

      this.sock.ev.on('creds.update', saveCreds);

    } catch (err) {
      logger.error('خطأ في بدء تشغيل البوت:', err);
      setTimeout(() => this.startBot(), 3000);
    }
  }

  async requestPairingCode(phoneNumber: string): Promise<string> {
    try {
      // Clear old session to create a fresh pairing
      const sessionDir = path.join(__dirname, '../../session');
      await fs.emptyDir(sessionDir);
      logger.info('🧹 تم مسح الجلسة القديمة');

      // Recreate socket with fresh auth state
      const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

      this.sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        browser: Browsers.ubuntu('Chrome'),
        logger: pino({ level: 'silent' }),
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true
      });

      // Wait for connection to be ready
      const connectionReady = new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Connection timeout'));
        }, 15000);

        this.sock.ev.on('connection.update', async (update: any) => {
          const { connection, lastDisconnect, qr } = update;

          if (connection === 'connecting') {
            logger.info('🔌 جاري الاتصال بواتساب...');
            await this.updateBotStatus('connecting');
            
            // Connection is ready for pairing when connecting and not registered
            if (!this.sock.authState.creds.registered) {
              clearTimeout(timeout);
              resolve();
            }
          }

          if (connection === 'open') {
            logger.success(`🎉 مستر مياو متصل! USER ID: ${this.sock.user.id}`);
            this.isConnected = true;
            
            await this.updateBotStatus('connected');
            
            // Add bot number to elite automatically
            try {
              const botNumber = this.sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
              await storage.addEliteNumber(botNumber, 'system');
              logger.info(`⭐ تم إضافة رقم البوت ${botNumber} للنخبة تلقائياً`);
            } catch (e) {
              logger.error('فشل في إضافة رقم البوت للنخبة:', e);
            }
          }

          if (connection === 'close') {
            const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            logger.warn(`💔 انقطع الاتصال: ${lastDisconnect?.error?.message || 'سبب غير معروف'}`);
            
            this.isConnected = false;
            await this.updateBotStatus('disconnected');

            if (isLoggedOut) {
              logger.error('🚪 تم تسجيل الخروج من الحساب - يرجى طلب كود ربط جديد من لوحة التحكم');
            } else if (statusCode === DisconnectReason.connectionClosed || 
                       statusCode === DisconnectReason.connectionLost ||
                       statusCode === DisconnectReason.connectionReplaced) {
              logger.info('🔄 محاولة إعادة الاتصال...');
              setTimeout(() => this.startBot(), 3000);
            } else {
              logger.warn('⏸️ البوت في وضع الانتظار - استخدم لوحة التحكم للاتصال');
            }
          }
        });
      });

      this.sock.ev.on('messages.upsert', async (m: any) => {
        try {
          await handleMessage(this.sock, m, storage);
        } catch (err) {
          logger.error('خطأ في معالجة الرسالة:', err);
        }
      });

      this.sock.ev.on('creds.update', saveCreds);

      // Wait for connection to be ready before requesting pairing code
      await connectionReady;
      
      // Small delay to ensure connection is fully established
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Request pairing code with phone number in E.164 format
      const cleanNumber = phoneNumber.replace(/\D/g, ''); // Remove all non-digits
      
      if (!this.sock.authState.creds.registered) {
        const code = await this.sock.requestPairingCode(cleanNumber);
        logger.info(`📱 كود الربط صحيح لرقم ${cleanNumber}: ${code}`);
        return code;
      } else {
        throw new Error('الجهاز مسجل بالفعل');
      }
    } catch (error) {
      logger.error('فشل في توليد كود الربط:', error);
      throw error;
    }
  }

  private async updateBotStatus(status: string) {
    try {
      let session = await storage.getBotSession();
      if (session) {
        await storage.updateBotSession(session.id, { 
          status,
          lastConnected: status === 'connected' ? new Date() : session.lastConnected
        });
      }
    } catch (error) {
      logger.error('فشل في تحديث حالة البوت:', error);
    }
  }

  isConnectedToWhatsApp(): boolean {
    return this.isConnected;
  }

  getSock() {
    return this.sock;
  }
}

export const bot = new WhatsAppBot();
