import chalk from 'chalk';

export class Logger {
  private getTimestamp(): string {
    return new Date().toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  }

  info(message: string) {
    console.log(`${chalk.blue(`[${this.getTimestamp()}]`)} ${chalk.cyan('[INFO]')} ${message}`);
  }

  success(message: string) {
    console.log(`${chalk.blue(`[${this.getTimestamp()}]`)} ${chalk.green('[SUCCESS]')} ${message}`);
  }

  warn(message: string) {
    console.log(`${chalk.blue(`[${this.getTimestamp()}]`)} ${chalk.yellow('[WARN]')} ${message}`);
  }

  error(message: string, error?: any) {
    console.log(`${chalk.blue(`[${this.getTimestamp()}]`)} ${chalk.red('[ERROR]')} ${message}`);
    if (error) {
      console.error(error);
    }
  }

  command(sender: string, command: string, group?: string) {
    const groupInfo = group ? chalk.magenta(`[${group}]`) : '';
    console.log(`${chalk.blue(`[${this.getTimestamp()}]`)} ${chalk.white('[CMD]')} ${groupInfo} ${chalk.yellow(sender)}: ${chalk.cyan(command)}`);
  }

  response(message: string) {
    console.log(`${chalk.blue(`[${this.getTimestamp()}]`)} ${chalk.magenta('[BOT]')} ${message}`);
  }
}

export const logger = new Logger();
