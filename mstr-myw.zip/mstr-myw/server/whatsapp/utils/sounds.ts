import { exec } from 'child_process';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { logger } from './logger';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export class SoundManager {
  private soundsDir: string;
  private isEnabled: boolean = true;

  constructor() {
    this.soundsDir = path.join(__dirname, '../../../sounds');
    this.ensureSoundsDirectory();
    this.checkSoundStatus();
  }

  private async ensureSoundsDirectory() {
    try {
      await fs.ensureDir(this.soundsDir);
    } catch (error) {
      logger.error('فشل في إنشاء مجلد الأصوات:', error);
    }
  }

  private checkSoundStatus() {
    try {
      const controlPath = path.join(this.soundsDir, 'sound.txt');
      if (fs.existsSync(controlPath)) {
        const status = fs.readFileSync(controlPath, 'utf-8').trim();
        this.isEnabled = status === '{on}';
      }
    } catch (error) {
      logger.warn('تعذر قراءة حالة الأصوات:' + error);
    }
  }

  async playSound(soundName: string): Promise<void> {
    if (!this.isEnabled) {
      return;
    }

    try {
      const soundPath = path.join(this.soundsDir, soundName);
      
      if (!fs.existsSync(soundPath)) {
        logger.warn(`الملف الصوتي غير موجود: ${soundName}`);
        return;
      }

      // Try to play sound using available audio player
      const players = ['mpv', 'ffplay', 'paplay', 'aplay'];
      
      for (const player of players) {
        try {
          await this.tryPlayer(player, soundPath);
          logger.info(`تم تشغيل الصوت: ${soundName}`);
          return;
        } catch (error) {
          continue;
        }
      }
      
      logger.warn('لا يوجد مشغل صوت متاح');
    } catch (error) {
      logger.error(`فشل في تشغيل الصوت ${soundName}:`, error);
    }
  }

  private tryPlayer(player: string, soundPath: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const command = `${player} --no-terminal --really-quiet "${soundPath}" 2>/dev/null`;
      
      exec(command, (error) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      });
    });
  }

  async setSoundEnabled(enabled: boolean): Promise<void> {
    try {
      this.isEnabled = enabled;
      const controlPath = path.join(this.soundsDir, 'sound.txt');
      const status = enabled ? '{on}' : '{off}';
      
      await fs.writeFile(controlPath, status, 'utf-8');
      logger.info(`تم ${enabled ? 'تفعيل' : 'إلغاء'} الأصوات`);
    } catch (error) {
      logger.error('فشل في تحديث حالة الأصوات:', error);
    }
  }

  isSoundEnabled(): boolean {
    return this.isEnabled;
  }

  // Predefined sound events
  async playWelcome(): Promise<void> {
    await this.playSound('WELCOME.mp3');
  }

  async playError(): Promise<void> {
    await this.playSound('ERROR.mp3');
  }

  async playSuccess(): Promise<void> {
    await this.playSound('SUCCESS.mp3');
  }

  async playLogout(): Promise<void> {
    await this.playSound('LOGOUT.mp3');
  }

  async playStartup(): Promise<void> {
    await this.playSound('ANASTASIA.mp3');
  }

  async playCommand(): Promise<void> {
    await this.playSound('COMMAND.mp3');
  }

  async playAnime(): Promise<void> {
    await this.playSound('ANIME.mp3');
  }

  async playChallenge(): Promise<void> {
    await this.playSound('CHALLENGE.mp3');
  }
}

export const soundManager = new SoundManager();

// Sound event constants
export const SOUND_EVENTS = {
  WELCOME: 'WELCOME.mp3',
  ERROR: 'ERROR.mp3',
  SUCCESS: 'SUCCESS.mp3',
  LOGOUT: 'LOGOUT.mp3',
  STARTUP: 'ANASTASIA.mp3',
  COMMAND: 'COMMAND.mp3',
  ANIME: 'ANIME.mp3',
  CHALLENGE: 'CHALLENGE.mp3'
} as const;

export type SoundEvent = keyof typeof SOUND_EVENTS;

// Helper function for backwards compatibility
export function playSound(soundName: string): void {
  soundManager.playSound(soundName).catch(error => {
    logger.error(`فشل في تشغيل الصوت ${soundName}:`, error);
  });
}

