import { storage } from '../../storage';
import { logger } from '../utils/logger';
import { commands } from '../commands';
import { getRandomResponse } from '../utils/responses';

export async function handleMessage(sock: any, m: any, storageInstance: typeof storage) {
  try {
    const msg = m.messages?.[0];
    if (!msg || msg.key.fromMe) return;

    const messageType = Object.keys(msg.message || {})[0];
    if (messageType !== 'conversation' && messageType !== 'extendedTextMessage') return;

    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    if (!text.startsWith('.')) return;

    const sender = msg.key.remoteJid?.endsWith('@g.us') 
      ? msg.key.participant?.split('@')[0] 
      : msg.key.remoteJid?.split('@')[0];
    
    const groupId = msg.key.remoteJid?.endsWith('@g.us') ? msg.key.remoteJid : null;
    const isGroup = !!groupId;
    
    const [command, ...args] = text.slice(1).split(' ');
    const commandLower = command.toLowerCase();

    const startTime = Date.now();
    
    // Log the command
    logger.command(sender || 'Unknown', text, groupId);

    // Check if command exists
    const commandHandler = commands[commandLower];
    if (!commandHandler) {
      const errorResponse = getRandomResponse('errors');
      await sock.sendMessage(msg.key.remoteJid, { text: errorResponse });
      return;
    }

    // Check permissions
    const isElite = await storageInstance.isEliteNumber(sender || '');
    const isAdmin = isElite; // For now, elite members are admins
    
    if (commandHandler.adminOnly && !isAdmin) {
      const unauthorizedResponse = getRandomResponse('unauthorized');
      await sock.sendMessage(msg.key.remoteJid, { text: unauthorizedResponse });
      return;
    }

    // Execute command
    try {
      const response = await commandHandler.execute({
        sock,
        sender: sender || '',
        groupId,
        isGroup,
        isAdmin,
        isElite,
        args,
        msg,
        storage: storageInstance
      });

      if (response) {
        if (typeof response === 'string') {
          await sock.sendMessage(msg.key.remoteJid, { text: response });
        } else if (response.type === 'image') {
          await sock.sendMessage(msg.key.remoteJid, {
            image: { url: response.url },
            caption: response.caption || ''
          });
        } else if (response.type === 'video') {
          await sock.sendMessage(msg.key.remoteJid, {
            video: { url: response.url },
            caption: response.caption || ''
          });
        }
      }

      const executionTime = Date.now() - startTime;
      
      // Log the command execution
      await storageInstance.createCommandLog({
        command: text,
        sender: sender || '',
        groupId,
        response: typeof response === 'string' ? response : JSON.stringify(response),
        executionTime
      });

      logger.response(`تم تنفيذ الأمر ${command} في ${executionTime}ms`);

    } catch (error) {
      logger.error(`خطأ في تنفيذ الأمر ${command}:`, error);
      const errorResponse = getRandomResponse('errors');
      await sock.sendMessage(msg.key.remoteJid, { text: errorResponse });
    }

  } catch (error) {
    logger.error('خطأ في معالجة الرسالة:', error);
  }
}
