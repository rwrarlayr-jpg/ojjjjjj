import { Command } from '../index';

export const movieCommand: Command = {
  name: 'فيلم',
  description: 'معلومات عن الأفلام',
  category: 'entertainment',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const movieName = args.join(' ');
    
    if (!movieName) {
      return '🎬 أدخل اسم الفيلم\nمثال: .فيلم The Dark Knight';
    }
    
    const movies: Record<string, any> = {
      'the dark knight': {
        title: 'The Dark Knight',
        year: '2008',
        director: 'Christopher Nolan',
        rating: '9.0/10',
        genre: 'Action, Crime, Drama',
        description: 'باتمان يواجه الجوكر في معركة ملحمية'
      },
      'inception': {
        title: 'Inception',
        year: '2010',
        director: 'Christopher Nolan',
        rating: '8.8/10',
        genre: 'Sci-Fi, Action',
        description: 'رحلة عبر الأحلام والعقل الباطن'
      }
    };
    
    const movie = movies[movieName.toLowerCase()];
    
    if (!movie) {
      return `🎬 لم أجد معلومات عن "${movieName}"\nجرب أسماء أفلام مشهورة باللغة الإنجليزية`;
    }
    
    return `🎬 *${movie.title}* (${movie.year})\n\n🎯 التقييم: ${movie.rating}\n🎭 النوع: ${movie.genre}\n👨‍💼 المخرج: ${movie.director}\n📝 الوصف: ${movie.description}\n\n🐱🎥 مستر مياو يحب السينما!`;
  }
};

export const musicCommand: Command = {
  name: 'موسيقى', 
  description: 'أغاني وألبومات',
  category: 'entertainment',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const query = args.join(' ');
    
    if (!query) {
      const randomSongs = [
        '🎵 "عامل إيه" - عمرو دياب',
        '🎶 "لمّا بضحك" - محمد منير',
        '🎵 "ألف ليلة وليلة" - أم كلثوم',
        '🎶 "يا مسهرني" - محمد عبد الوهاب',
        '🎵 "زي الهوا" - فيروز'
      ];
      
      const randomSong = randomSongs[Math.floor(Math.random() * randomSongs.length)];
      return `🎼 *أغنية اليوم* 🎼\n\n${randomSong}\n\n🐱🎵 مستر مياو يختار لك الأفضل!`;
    }
    
    return `🎼 *البحث عن الموسيقى* 🎼\n\n🔍 بحث عن: "${query}"\n📻 النتائج: قيد التحديث...\n\n🐱🎶 مستر مياو يجلب لك أجمل الألحان!`;
  }
};

export const tvShowCommand: Command = {
  name: 'مسلسل',
  description: 'معلومات عن المسلسلات',
  category: 'entertainment',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const showName = args.join(' ');
    
    if (!showName) {
      return '📺 أدخل اسم المسلسل\nمثال: .مسلسل Breaking Bad';
    }
    
    const shows: Record<string, any> = {
      'breaking bad': {
        title: 'Breaking Bad',
        seasons: '5 مواسم',
        episodes: '62 حلقة',
        rating: '9.5/10',
        genre: 'Crime, Drama',
        description: 'مدرس كيمياء يتحول لصانع مخدرات'
      },
      'game of thrones': {
        title: 'Game of Thrones',
        seasons: '8 مواسم',
        episodes: '73 حلقة', 
        rating: '9.3/10',
        genre: 'Fantasy, Drama',
        description: 'صراع العروش في عالم خيالي ملحمي'
      }
    };
    
    const show = shows[showName.toLowerCase()];
    
    if (!show) {
      return `📺 لم أجد معلومات عن "${showName}"\nجرب أسماء مسلسلات مشهورة`;
    }
    
    return `📺 *${show.title}*\n\n📊 المواسم: ${show.seasons}\n🎬 الحلقات: ${show.episodes}\n⭐ التقييم: ${show.rating}\n🎭 النوع: ${show.genre}\n📝 الوصف: ${show.description}\n\n🐱📺 مستر مياو يتابع كل شيء!`;
  }
};

export const bookCommand: Command = {
  name: 'كتاب',
  description: 'معلومات عن الكتب',
  category: 'entertainment',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const bookName = args.join(' ');
    
    if (!bookName) {
      const recommendations = [
        '📚 "مئة عام من العزلة" - غابرييل غارسيا ماركيز',
        '📖 "الأسود يليق بك" - أحلام مستغانمي',
        '📚 "مدن الملح" - عبد الرحمن منيف',
        '📖 "ثلاثية غرناطة" - رضوى عاشور',
        '📚 "عزازيل" - يوسف زيدان'
      ];
      
      const randomBook = recommendations[Math.floor(Math.random() * recommendations.length)];
      return `📚 *ترشيح اليوم* 📚\n\n${randomBook}\n\n🐱📖 قراءة ممتعة من مستر مياو!`;
    }
    
    return `📚 *البحث عن الكتب* 📚\n\n🔍 بحث عن: "${bookName}"\n📖 النتائج: قيد التحديث...\n\n🐱📚 مستر مياو محب للقراءة!`;
  }
};

export const newsCommand: Command = {
  name: 'أخبار',
  description: 'آخر الأخبار',
  category: 'entertainment',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const category = args[0]?.toLowerCase() || 'عامة';
    
    const news = {
      'رياضة': [
        '⚽ الأهلي يفوز على الزماlek في القمة',
        '🏆 محمد صلاح يسجل هدفين في مباراة ليفربول',
        '🎾 جونسون يتأهل لنصف نهائي ويمبلدون'
      ],
      'تكنولوجيا': [
        '💻 آبل تكشف عن iPhone جديد',
        '🤖 تطورات جديدة في الذكاء الاصطناعي',
        '🚀 سبيس إكس تطلق مهمة جديدة للمريخ'
      ],
      'عامة': [
        '🌍 مؤتمر المناخ يناقش حلول جديدة',
        '💼 نمو الاقتصاد المصري بنسبة 5%',
        '🏥 اكتشاف علاج جديد لمرض نادر'
      ]
    };
    
    const categoryNews = news[category as keyof typeof news] || news['عامة'];
    const randomNews = categoryNews[Math.floor(Math.random() * categoryNews.length)];
    
    return `📰 *أخبار ${category}* 📰\n\n${randomNews}\n\n🐱📺 مستر مياو يتابع كل جديد!\n\nالفئات: رياضة، تكنولوجيا، عامة`;
  }
};