import { Command } from '../index';

export const calcCommand: Command = {
  name: 'حساب',
  description: 'آلة حاسبة بسيطة',
  category: 'utility',
  adminOnly: false,
  execute: async ({ args }) => {
    const expression = args.join(' ');
    
    if (!expression) {
      return '🧮 أدخل عملية حسابية\nمثال: .حساب 5 + 3 * 2';
    }
    
    try {
      // Safe math evaluation - only allow basic operations
      const safeExpression = expression.replace(/[^0-9+\-*/().\s]/g, '');
      if (safeExpression !== expression) {
        return '⚠️ استخدم الأرقام والعمليات الأساسية فقط (+, -, *, /, ())';
      }
      
      const result = eval(safeExpression);
      
      if (isNaN(result) || !isFinite(result)) {
        return '❌ عملية حسابية غير صحيحة!';
      }
      
      return `🧮 *الحاسبة* 🧮\n\n📊 العملية: ${expression}\n🎯 النتيجة: **${result}**\n\n🐱📐 مستر مياو يحسب بدقة!`;
    } catch (error) {
      return '❌ خطأ في العملية الحسابية! تأكد من صحة الصيغة.';
    }
  }
};

export const encodeCommand: Command = {
  name: 'تشفير',
  description: 'تشفير النص (Base64)',
  category: 'utility',
  adminOnly: false,
  execute: async ({ args }) => {
    const text = args.join(' ');
    
    if (!text) {
      return '🔐 أدخل النص المراد تشفيره\nمثال: .تشفير مرحبا بالعالم';
    }
    
    try {
      const encoded = Buffer.from(text, 'utf8').toString('base64');
      return `🔐 *التشفير* 🔐\n\n📝 النص الأصلي: ${text}\n🔒 النص المشفر: ${encoded}\n\n🐱🔑 مستر مياو يحمي أسرارك!`;
    } catch (error) {
      return '❌ خطأ في التشفير!';
    }
  }
};

export const decodeCommand: Command = {
  name: 'فك_تشفير',
  description: 'فك تشفير النص (Base64)',
  category: 'utility',
  adminOnly: false,
  execute: async ({ args }) => {
    const encodedText = args.join(' ');
    
    if (!encodedText) {
      return '🔓 أدخل النص المشفر المراد فك تشفيره\nمثال: .فك_تشفير SGVsbG8gV29ybGQ=';
    }
    
    try {
      const decoded = Buffer.from(encodedText, 'base64').toString('utf8');
      return `🔓 *فك التشفير* 🔓\n\n🔒 النص المشفر: ${encodedText}\n📝 النص الأصلي: ${decoded}\n\n🐱🔓 مستر مياو يكشف الأسرار!`;
    } catch (error) {
      return '❌ خطأ في فك التشفير! تأكد من صحة النص المشفر.';
    }
  }
};

export const qrCommand: Command = {
  name: 'كيو_ار',
  description: 'إنشاء رمز QR للنص',
  category: 'utility',
  adminOnly: false,
  execute: async ({ args }) => {
    const text = args.join(' ');
    
    if (!text) {
      return '📱 أدخل النص المراد تحويله لرمز QR\nمثال: .كيو_ار https://example.com';
    }
    
    // Since we can't generate actual QR codes, we'll provide a service link
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(text)}`;
    
    return `📱 *رمز QR* 📱\n\n📝 النص: ${text}\n🔗 رابط الرمز: ${qrUrl}\n\n🐱📱 مستر مياو يحول كل شيء لرمز!`;
  }
};

export const shortenCommand: Command = {
  name: 'اختصار_رابط',
  description: 'اختصار الروابط الطويلة',
  category: 'utility',
  adminOnly: false,
  execute: async ({ args }) => {
    const url = args.join(' ');
    
    if (!url) {
      return '🔗 أدخل الرابط المراد اختصاره\nمثال: .اختصار_رابط https://example.com/very/long/url';
    }
    
    // Simple URL validation
    try {
      new URL(url);
    } catch {
      return '❌ رابط غير صحيح! تأكد من أن الرابط يبدأ بـ http:// أو https://';
    }
    
    // Generate a mock shortened URL (in real implementation, use a URL shortening service)
    const shortId = Math.random().toString(36).substring(2, 8);
    const shortUrl = `https://short.ly/${shortId}`;
    
    return `🔗 *اختصار الرابط* 🔗\n\n📎 الرابط الأصلي:\n${url}\n\n✂️ الرابط المختصر:\n${shortUrl}\n\n🐱🔗 مستر مياو يوفر عليك المساحة!`;
  }
};

export const translateCommand: Command = {
  name: 'ترجمة',
  description: 'ترجمة النصوص',
  category: 'utility',
  adminOnly: false,
  execute: async ({ args }) => {
    if (args.length < 2) {
      return '🌐 الاستخدام: .ترجمة [اللغة] [النص]\nمثال: .ترجمة انجليزي مرحبا بالعالم\nاللغات المتاحة: انجليزي، فرنسي، اسباني، الماني';
    }
    
    const targetLang = args[0].toLowerCase();
    const text = args.slice(1).join(' ');
    
    // Mock translation (in real implementation, use Google Translate API)
    const translations: Record<string, Record<string, string>> = {
      'انجليزي': {
        'مرحبا': 'Hello',
        'شكرا': 'Thank you',
        'صباح الخير': 'Good morning',
        'مساء الخير': 'Good evening',
        'كيف حالك': 'How are you',
        'أحبك': 'I love you'
      },
      'فرنسي': {
        'مرحبا': 'Bonjour',
        'شكرا': 'Merci',
        'صباح الخير': 'Bonjour',
        'مساء الخير': 'Bonsoir',
        'كيف حالك': 'Comment allez-vous',
        'أحبك': 'Je t\'aime'
      }
    };
    
    const langTranslations = translations[targetLang];
    if (!langTranslations) {
      return '❌ لغة غير مدعومة! اللغات المتاحة: انجليزي، فرنسي';
    }
    
    const translated = langTranslations[text.toLowerCase()] || `[ترجمة ${text} إلى ${targetLang}]`;
    
    return `🌐 *الترجمة* 🌐\n\n📝 النص الأصلي: ${text}\n🎯 اللغة: ${targetLang}\n✨ الترجمة: ${translated}\n\n🐱🌍 مستر مياو يتكلم كل اللغات!`;
  }
};