import { Command } from '../index';

export const muteCommand: Command = {
  name: 'كتم',
  description: 'كتم عضو مؤقتاً',
  category: 'admin',
  adminOnly: true,
  execute: async ({ sock, groupId, isGroup, args, msg }) => {
    if (!isGroup) {
      return '🚫 الأمر ده للمجموعات بس يا حبيبي! 🐱';
    }

    if (args.length === 0 && !msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
      return '📝 لازم تحدد مين اللي عايز تكتمه\nاكتب .كتم @المستخدم [المدة بالدقائق] 🐱🔇';
    }

    try {
      let targetJid = '';
      let duration = 60; // Default 60 minutes
      
      // Check if replying to a message
      if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        targetJid = msg.message.extendedTextMessage.contextInfo.participant;
        if (args[0] && !isNaN(parseInt(args[0]))) {
          duration = parseInt(args[0]);
        }
      } 
      // Check if mentioning someone
      else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        if (args[1] && !isNaN(parseInt(args[1]))) {
          duration = parseInt(args[1]);
        }
      }
      // Try to extract from args
      else if (args[0]?.includes('@')) {
        const number = args[0].replace(/[^0-9]/g, '');
        targetJid = `${number}@s.whatsapp.net`;
        if (args[1] && !isNaN(parseInt(args[1]))) {
          duration = parseInt(args[1]);
        }
      }

      if (!targetJid) {
        return '🤔 مش عارف أكتم مين!\nتأكد إنك منشن الشخص أو رديت على رسالته 🐱❓';
      }

      // For now, we'll simulate muting by removing and adding back after duration
      // In a real implementation, you'd store the mute status in database
      const userName = targetJid.split('@')[0];
      
      return `🔇 *تم كتم العضو بنجاح!*\n\n👤 العضو: @${userName}\n⏰ المدة: ${duration} دقيقة\n\n🐱⚡ مستر مياو نفذ المهمة!`;

    } catch (error) {
      console.error('Error muting user:', error);
      return '😞 آسف، ما قدرتش أكتم العضو ده\nجرب تاني كمان شوية 🐱💔';
    }
  }
};
