import { Command } from '../index';

export const cleanCommand: Command = {
  name: 'تنظيف',
  description: 'حذف رسائل متعددة',
  category: 'admin',
  adminOnly: true,
  execute: async ({ sock, groupId, isGroup, args }) => {
    if (!isGroup) {
      return '🚫 الأمر ده للمجموعات بس يا حبيبي! 🐱';
    }

    const count = parseInt(args[0]) || 10;
    
    if (count < 1 || count > 100) {
      return '📊 لازم العدد يكون من 1 لـ 100 رسالة\nمثال: .تنظيف 20 🐱🧹';
    }

    try {
      // Note: WhatsApp doesn't allow bulk message deletion through Baileys
      // This is a limitation of the WhatsApp Business API
      // We'll provide feedback about this limitation
      
      return `🧹 *تنظيف المجموعة*\n\n⚠️ للأسف، واتساب ما بيسمحش بحذف رسائل متعددة تلقائياً\n\n💡 *البدائل المتاحة:*\n• احذف الرسائل يدوياً\n• استخدم خاصية "حذف للجميع" لكل رسالة\n• غير إعدادات المجموعة لـ "الأدمن فقط"\n\n🐱⚡ آسف للإزعاج، مستر مياو بيحاول يساعد قد ما يقدر!`;

    } catch (error) {
      console.error('Error cleaning messages:', error);
      return '😞 آسف، ما قدرتش أنظف الرسائل\nجرب تاني كمان شوية 🐱💔';
    }
  }
};
