import { Command } from '../index';

export const welcomeCommand: Command = {
  name: 'ترحيب',
  description: 'تعديل رسالة الترحيب',
  category: 'admin',
  adminOnly: true,
  execute: async ({ groupId, isGroup, args, storage }) => {
    if (!isGroup) {
      return '🚫 الأمر ده للمجموعات بس يا حبيبي! 🐱';
    }

    if (args.length === 0) {
      // Show current welcome message
      const settings = await storage.getGroupSettings(groupId);
      const currentMessage = settings?.welcomeMessage || 'لا توجد رسالة ترحيب مخصصة';
      
      return `📋 *رسالة الترحيب الحالية:*\n\n${currentMessage}\n\n💡 *لتغيير الرسالة:*\n.ترحيب [الرسالة الجديدة]`;
    }

    const newMessage = args.join(' ');
    
    try {
      await storage.updateGroupSettings(groupId, {
        welcomeMessage: newMessage
      });
      
      return `✅ *تم تحديث رسالة الترحيب بنجاح!* 🎉\n\n📝 *الرسالة الجديدة:*\n${newMessage}\n\n🐱⚡ مستر مياو في خدمتك!`;
    } catch (error) {
      console.error('Error updating welcome message:', error);
      return '😞 آسف، ما قدرتش أحدث رسالة الترحيب\nجرب تاني كمان شوية 🐱💔';
    }
  }
};
