import { Command } from '../index';

export const eliteCommand: Command = {
  name: 'نخبة',
  description: 'إدارة أرقام النخبة',
  category: 'admin',
  adminOnly: true,
  execute: async ({ args, storage, sender, msg }) => {
    const action = args[0]?.toLowerCase();
    
    if (!action || !['اضافة', 'حذف', 'قائمة', 'add', 'remove', 'list'].includes(action)) {
      return `⭐ *إدارة النخبة - مستر مياو* ⭐\n\n📋 *الأوامر المتاحة:*\n• .نخبة اضافة @المستخدم\n• .نخبة حذف @المستخدم\n• .نخبة قائمة\n\n🐱👑 النخبة لها صلاحيات خاصة!`;
    }

    try {
      if (action === 'قائمة' || action === 'list') {
        const eliteNumbers = await storage.getEliteNumbers();
        
        if (eliteNumbers.length === 0) {
          return '📋 *قائمة النخبة فارغة*\n\nما في حد في النخبة دلوقتي\nاستخدم .نخبة اضافة لإضافة أعضاء جدد 🐱⭐';
        }
        
        let listText = '⭐ *قائمة أعضاء النخبة* ⭐\n\n';
        eliteNumbers.forEach((elite: any, index: number) => {
          const addedDate = elite.addedAt ? new Date(elite.addedAt).toLocaleDateString('ar-EG') : 'غير محدد';
          listText += `${index + 1}. @${elite.phoneNumber}\n   📅 تاريخ الإضافة: ${addedDate}\n\n`;
        });
        
        return listText + '🐱👑 هؤلاء هم نخبة مستر مياو!';
      }
      
      if (action === 'اضافة' || action === 'add') {
        let targetNumber = '';
        
        // Check if mentioning someone
        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
          targetNumber = msg.message.extendedTextMessage.contextInfo.mentionedJid[0].split('@')[0];
        }
        // Try to extract from args
        else if (args[1]?.includes('@')) {
          targetNumber = args[1].replace(/[^0-9]/g, '');
        }
        // Check if replying to a message
        else if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
          targetNumber = msg.message.extendedTextMessage.contextInfo.participant.split('@')[0];
        }
        
        if (!targetNumber) {
          return '📝 لازم تحدد مين اللي عايز تضيفه للنخبة\nاكتب .نخبة اضافة @المستخدم 🐱⭐';
        }
        
        const isAlreadyElite = await storage.isEliteNumber(targetNumber);
        if (isAlreadyElite) {
          return `⭐ @${targetNumber} موجود في النخبة فعلاً!\nمش محتاج إضافة تاني 🐱👑`;
        }
        
        await storage.addEliteNumber(targetNumber, sender);
        return `🎉 *تم إضافة عضو جديد للنخبة!* 🎉\n\n⭐ العضو: @${targetNumber}\n👑 أضافه: @${sender}\n\n🐱⚡ مرحباً بالعضو الجديد في النخبة!`;
      }
      
      if (action === 'حذف' || action === 'remove') {
        let targetNumber = '';
        
        // Check if mentioning someone
        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
          targetNumber = msg.message.extendedTextMessage.contextInfo.mentionedJid[0].split('@')[0];
        }
        // Try to extract from args
        else if (args[1]?.includes('@')) {
          targetNumber = args[1].replace(/[^0-9]/g, '');
        }
        
        if (!targetNumber) {
          return '📝 لازم تحدد مين اللي عايز تشيله من النخبة\nاكتب .نخبة حذف @المستخدم 🐱⭐';
        }
        
        const isElite = await storage.isEliteNumber(targetNumber);
        if (!isElite) {
          return `❌ @${targetNumber} مش موجود في النخبة أصلاً!\nتأكد من الرقم 🐱💔`;
        }
        
        await storage.removeEliteNumber(targetNumber);
        return `💔 *تم حذف عضو من النخبة*\n\n⭐ العضو: @${targetNumber}\n👑 حذفه: @${sender}\n\n🐱😿 وداعاً أيها العضو السابق...`;
      }
      
    } catch (error) {
      console.error('Error managing elite:', error);
      return '😞 آسف، حصل خطأ في إدارة النخبة\nجرب تاني كمان شوية 🐱💔';
    }
  }
};
