import { Command } from '../index';
import { getRandomResponse } from '../../utils/responses';

export const kickCommand: Command = {
  name: 'طرد',
  description: 'طرد عضو من المجموعة',
  category: 'admin',
  adminOnly: true,
  execute: async ({ sock, groupId, isGroup, args, msg }) => {
    if (!isGroup) {
      return '🚫 الأمر ده للمجموعات بس يا حبيبي! 🐱';
    }

    if (args.length === 0 && !msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
      return '📝 لازم تحدد مين اللي عايز تطرده\nاكتب .طرد @المستخدم أو رد على رسالته 🐱⚡';
    }

    try {
      let targetJid = '';
      
      // Check if replying to a message
      if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        targetJid = msg.message.extendedTextMessage.contextInfo.participant;
      } 
      // Check if mentioning someone
      else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
      }
      // Try to extract from args
      else if (args[0]?.includes('@')) {
        const number = args[0].replace(/[^0-9]/g, '');
        targetJid = `${number}@s.whatsapp.net`;
      }

      if (!targetJid) {
        return '🤔 مش عارف أطرد مين!\nتأكد إنك منشن الشخص أو رديت على رسالته 🐱❓';
      }

      // Get group metadata to check if user is member
      const groupMetadata = await sock.groupMetadata(groupId);
      const isMember = groupMetadata.participants.some((p: any) => p.id === targetJid);
      
      if (!isMember) {
        return '😅 الشخص ده مش موجود في المجموعة أصلاً!\nولا هو هرب قبل ما أطرده؟ 🐱💨';
      }

      // Kick the user
      await sock.groupParticipantsUpdate(groupId, [targetJid], 'remove');
      
      const userName = targetJid.split('@')[0];
      return getRandomResponse('kick', { user: userName });

    } catch (error) {
      console.error('Error kicking user:', error);
      return '😞 آسف، ما قدرتش أطرد العضو ده\nممكن ما بقاش موجود أو أنا مش أدمن هنا 🐱💔';
    }
  }
};
