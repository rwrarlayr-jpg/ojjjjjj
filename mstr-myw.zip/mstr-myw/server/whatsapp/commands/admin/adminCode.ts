import { Command } from '../index';

export const adminCodeCommand: Command = {
  name: 'كود_ادمن',
  description: 'استخدام كود سري للحصول على صلاحيات الأدمن',
  category: 'admin',
  adminOnly: false,
  execute: async ({ args, sender, storage }) => {
    if (!args.length) {
      return '🔐 *كود الأدمن السري* 🔐\n\nعشان تبقى أدمن، لازم يكون معاك الكود السري!\n\n📝 استخدم: .كود_ادمن [الكود]\n\n🐱🔒 الكود ده سري جداً!';
    }

    const code = args[0].toUpperCase();
    const isValid = await storage.validateAdminCode(code, sender);
    
    if (isValid) {
      return `🎉 *مبروك! تم ترقيتك لأدمن!* 🎉\n\n👑 أصبحت الآن من النخبة!\n⚡ لديك صلاحيات الأدمن الكاملة\n🔥 يمكنك استخدام جميع أوامر الأدمن\n\n🐱⭐ مرحباً بك في عائلة مستر مياو!`;
    } else {
      return `❌ *كود خاطئ!* ❌\n\n🔒 الكود اللي كتبته مش صحيح أو تم استخدامه قبل كده\n💭 لو عندك الكود الصحيح، جرب تاني\n\n🐱🔐 الكود السري محمي جداً!`;
    }
  }
};
