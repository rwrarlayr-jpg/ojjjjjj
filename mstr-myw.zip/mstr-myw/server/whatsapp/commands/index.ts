import { kickCommand } from './admin/kick';
import { welcomeCommand } from './admin/welcome';
import { muteCommand } from './admin/mute';
import { cleanCommand } from './admin/clean';
import { eliteCommand } from './admin/elite';
import { adminCodeCommand } from './admin/adminCode';
import { animeCommand } from './anime/anime';
import { waifuCommand } from './anime/waifu';
import { mangaCommand } from './anime/manga';
import { quoteCommand } from './anime/quote';
import { kawaiiCommand } from './anime/kawaii';
import { eyeChallengeCommand, answerCommand } from './challenges/eyeChallenge';
import { characterChallengeCommand } from './challenges/characterChallenge';
import { riddleCommand } from './challenges/riddle';
import { competitionCommand } from './challenges/competition';
import { luckCommand } from './challenges/luck';

// New command imports
import { jokesCommand } from './fun/jokes';
import { memesCommand } from './fun/memes';
import { diceCommand, flipCommand, randomNumberCommand, rockPaperScissorsCommand } from './fun/games';
import { quotesCommand, wisdomCommand } from './fun/quotes';
import { calcCommand, encodeCommand, decodeCommand, qrCommand, shortenCommand, translateCommand } from './utility/tools';
import { whoAmICommand, groupInfoCommand, profileCommand, topUsersCommand, statsCommand } from './social/info';
import { rankCommand, leaderboardCommand } from './social/rank';
import { movieCommand, musicCommand, tvShowCommand, bookCommand, newsCommand } from './entertainment/media';
import { prayerTimesCommand, quranCommand, hadithCommand, dhikrCommand, islamicFactCommand } from './religious/islamic';

export interface CommandContext {
  sock: any;
  sender: string;
  groupId: string | null;
  isGroup: boolean;
  isAdmin: boolean;
  isElite: boolean;
  args: string[];
  msg: any;
  storage: any;
}

export interface Command {
  name: string;
  description: string;
  category: string;
  adminOnly: boolean;
  execute: (context: CommandContext) => Promise<string | any>;
}

export const commands: Record<string, Command> = {
  // Admin commands
  'طرد': kickCommand,
  'kick': kickCommand,
  'ترحيب': welcomeCommand,
  'welcome': welcomeCommand,
  'كتم': muteCommand,
  'mute': muteCommand,
  'تنظيف': cleanCommand,
  'clean': cleanCommand,
  'نخبة': eliteCommand,
  'elite': eliteCommand,
  'كود_ادمن': adminCodeCommand,
  'admin_code': adminCodeCommand,
  
  // Anime commands
  'انمي': animeCommand,
  'anime': animeCommand,
  'وايفو': waifuCommand,
  'waifu': waifuCommand,
  'مانجا': mangaCommand,
  'manga': mangaCommand,
  'اقتباس_انمي': quoteCommand,
  'anime_quote': quoteCommand,
  'كاواي': kawaiiCommand,
  'kawaii': kawaiiCommand,
  
  // Challenge commands
  'تحدي_عين': eyeChallengeCommand,
  'eye_challenge': eyeChallengeCommand,
  'جواب': answerCommand,
  'answer': answerCommand,
  'تحدي_شخصية': characterChallengeCommand,
  'character_challenge': characterChallengeCommand,
  'احجية': riddleCommand,
  'riddle': riddleCommand,
  'مسابقة': competitionCommand,
  'competition': competitionCommand,
  'حظ': luckCommand,
  'luck': luckCommand,
  
  // Fun commands  
  'نكتة': jokesCommand,
  'joke': jokesCommand,
  'ميم': memesCommand,
  'meme': memesCommand,
  'زهر': diceCommand,
  'dice': diceCommand,
  'عملة': flipCommand,
  'flip': flipCommand,
  'رقم': randomNumberCommand,
  'random': randomNumberCommand,
  'حجر_ورقة_مقص': rockPaperScissorsCommand,
  'rps': rockPaperScissorsCommand,
  'اقتباس': quotesCommand,
  'quote': quotesCommand,
  'حكمة': wisdomCommand,
  'wisdom': wisdomCommand,
  
  // Utility commands
  'حساب': calcCommand,
  'calc': calcCommand,
  'تشفير': encodeCommand,
  'encode': encodeCommand,
  'فك_تشفير': decodeCommand,
  'decode': decodeCommand,
  'كيو_ار': qrCommand,
  'qr': qrCommand,
  'اختصار_رابط': shortenCommand,
  'shorten': shortenCommand,
  'ترجمة': translateCommand,
  'translate': translateCommand,
  
  // Social commands
  'من_انا': whoAmICommand,
  'whoami': whoAmICommand,
  'معلومات_المجموعة': groupInfoCommand,
  'groupinfo': groupInfoCommand,
  'الملف_الشخصي': profileCommand,
  'profile': profileCommand,
  'رانك': rankCommand,
  'rank': rankCommand,
  'المتصدرين': leaderboardCommand,
  'leaderboard': leaderboardCommand,
  'احصائيات': statsCommand,
  'stats': statsCommand,
  
  // Entertainment commands
  'فيلم': movieCommand,
  'movie': movieCommand,
  'موسيقى': musicCommand,
  'music': musicCommand,
  'مسلسل': tvShowCommand,
  'tv': tvShowCommand,
  'كتاب': bookCommand,
  'book': bookCommand,
  'أخبار': newsCommand,
  'news': newsCommand,
  
  // Religious commands
  'مواقيت_الصلاة': prayerTimesCommand,
  'prayer': prayerTimesCommand,
  'قرآن': quranCommand,
  'quran': quranCommand,
  'حديث': hadithCommand,
  'hadith': hadithCommand,
  'أذكار': dhikrCommand,
  'dhikr': dhikrCommand,
  'معلومة_دينية': islamicFactCommand,
  'islamicfact': islamicFactCommand,
};

// Help command
export const helpCommand: Command = {
  name: 'مساعدة',
  description: 'عرض جميع الأوامر المتاحة',
  category: 'general',
  adminOnly: false,
  execute: async () => {
    let helpText = '🐱⚡ *مستر مياو - دليل الأوامر* ⚡🐱\n\n';
    
    const categories = {
      'admin': '👑 *أوامر الأدمن*',
      'anime': '🎌 *أوامر الأنمي*',
      'challenges': '🎮 *التحديات والألعاب*'
    };
    
    Object.entries(categories).forEach(([category, title]) => {
      helpText += `${title}\n`;
      Object.values(commands).forEach(cmd => {
        if (cmd.category === category) {
          helpText += `• .${cmd.name} - ${cmd.description}\n`;
        }
      });
      helpText += '\n';
    });
    
    helpText += '✨ *مستر مياو في خدمتك دايماً!* ✨';
    return helpText;
  }
};

commands['مساعدة'] = helpCommand;
commands['help'] = helpCommand;
commands['اوامر'] = helpCommand;
commands['commands'] = helpCommand;
