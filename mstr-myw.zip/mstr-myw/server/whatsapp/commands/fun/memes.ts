import { Command } from '../index';

export const memesCommand: Command = {
  name: 'ميم',
  description: 'ميمز وصور مضحكة',
  category: 'fun',
  adminOnly: false,
  execute: async () => {
    const memes = [
      {
        text: '💭 لما أمك تقولك: "إنت مين جايبك هنا؟"\nوإنت: "إنتِ!" 😂',
        image: null
      },
      {
        text: '🎮 لما تخسر في اللعبة وتقول: "اللعبة عندها مشكلة!"\nبس لما تكسب تقول: "أنا محترف!" 🏆',
        image: null
      },
      {
        text: '📱 لما حد يشوف تليفونك ويقولك: "بطارية ضعيفة"\nوإنت: "عارف، ما هو مش تليفونك!" 🔋',
        image: null
      },
      {
        text: '🍕 لما تطلب أكل وتقول: "مش جعان أوي"\nوتاكل الصحن كله! 😋',
        image: null
      },
      {
        text: '⏰ لما المنبه يرن تقول: "5 دقائق بس"\nتصحى تلاقي مفوت الشغل! 😴',
        image: null
      },
      {
        text: '💸 لما تقول: "هوفر فلوس الشهر ده"\nيوم 3 في الشهر: "فين الفلوس؟!" 💔',
        image: null
      }
    ];

    const randomMeme = memes[Math.floor(Math.random() * memes.length)];
    
    return `😂 *ميم اليوم* 😂\n\n${randomMeme.text}\n\n🐱💫 مستر مياو بيضحك معاك!`;
  }
};