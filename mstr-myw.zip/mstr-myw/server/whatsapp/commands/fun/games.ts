import { Command } from '../index';

export const diceCommand: Command = {
  name: 'زهر',  
  description: 'رمي النرد',
  category: 'fun',
  adminOnly: false,
  execute: async ({ args }) => {
    const sides = parseInt(args[0]) || 6;
    const count = parseInt(args[1]) || 1;
    
    if (sides < 2 || sides > 100) {
      return '🎲 عدد الأوجه يجب أن يكون بين 2 و 100!';
    }
    
    if (count < 1 || count > 10) {
      return '🎲 عدد النردات يجب أن يكون بين 1 و 10!';
    }
    
    const results = [];
    let total = 0;
    
    for (let i = 0; i < count; i++) {
      const result = Math.floor(Math.random() * sides) + 1;
      results.push(result);
      total += result;
    }
    
    const diceEmoji = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
    let message = '🎲 *نتيجة رمي النرد* 🎲\n\n';
    
    if (sides === 6 && count <= 6) {
      message += results.map(r => diceEmoji[r-1] || `[${r}]`).join(' ') + '\n\n';
    } else {
      message += `النتائج: ${results.join(', ')}\n\n`;
    }
    
    if (count > 1) {
      message += `📊 المجموع: ${total}\n`;
      message += `📈 المتوسط: ${(total/count).toFixed(1)}`;
    }
    
    return message + '\n\n🐱🎯 حظ سعيد من مستر مياو!';
  }
};

export const flipCommand: Command = {
  name: 'عملة',
  description: 'رمي العملة',
  category: 'fun',
  adminOnly: false,
  execute: async () => {
    const results = ['صورة 🪙', 'كتابة 📝'];
    const result = results[Math.floor(Math.random() * results.length)];
    
    const messages = [
      '🪙 العملة تدور في الهواء...',
      '✨ والنتيجة هي...',
      `🎯 ${result}!`
    ];
    
    return `🎲 *رمي العملة* 🎲\n\n${messages.join('\n')}\n\n🐱💫 مستر مياو يحدد المصير!`;
  }
};

export const randomNumberCommand: Command = {
  name: 'رقم',
  description: 'رقم عشوائي',
  category: 'fun',
  adminOnly: false,
  execute: async ({ args }) => {
    const min = parseInt(args[0]) || 1;
    const max = parseInt(args[1]) || 100;
    
    if (min >= max) {
      return '🔢 الرقم الأدنى يجب أن يكون أقل من الرقم الأعلى!';
    }
    
    if (max - min > 1000000) {
      return '🔢 المدى كبير جداً! الحد الأقصى مليون رقم.';
    }
    
    const randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
    
    return `🎲 *الرقم العشوائي* 🎲\n\n🔢 من ${min} إلى ${max}\n🎯 النتيجة: **${randomNum}**\n\n🐱🎪 مستر مياو اختارلك الرقم!`;
  }
};

export const rockPaperScissorsCommand: Command = {
  name: 'حجر_ورقة_مقص',
  description: 'لعبة حجر ورقة مقص',
  category: 'fun',
  adminOnly: false,
  execute: async ({ args }) => {
    const userChoice = args[0]?.toLowerCase();
    const choices = ['حجر', 'ورقة', 'مقص'];
    const emojis: Record<string, string> = { 'حجر': '🪨', 'ورقة': '📄', 'مقص': '✂️' };
    
    if (!userChoice || !choices.includes(userChoice)) {
      return '🎮 اختر: حجر، ورقة، أو مقص\nمثال: .حجر_ورقة_مقص حجر';
    }
    
    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    let result = '';
    
    if (userChoice === botChoice) {
      result = '🤝 تعادل!';
    } else if (
      (userChoice === 'حجر' && botChoice === 'مقص') ||
      (userChoice === 'ورقة' && botChoice === 'حجر') ||
      (userChoice === 'مقص' && botChoice === 'ورقة')
    ) {
      result = '🎉 فزت!';
    } else {
      result = '😸 مستر مياو فاز!';
    }
    
    return `🎮 *حجر ورقة مقص* 🎮\n\nأنت: ${emojis[userChoice] || ''} ${userChoice}\nمستر مياو: ${emojis[botChoice] || ''} ${botChoice}\n\n${result}\n\n🐱⚡ لعبة أخرى؟`;
  }
};