import { Command } from '../index';

export const quoteCommand: Command = {
  name: 'اقتباس_انمي',
  description: 'اقتباسات من الأنمي',
  category: 'anime',
  adminOnly: false,
  execute: async () => {
    const quotes = [
      {
        text: "إذا كنت لا تشارك شخصاً أحلامه، فلن تستطيع أن تشاركه الأمل",
        character: "ناروتو أوزوماكي",
        anime: "Naruto"
      },
      {
        text: "الأحلام لا تموت أبداً، ما دام هناك من يؤمن بها",
        character: "مونكي دي لوفي",
        anime: "One Piece"
      },
      {
        text: "القوة الحقيقية ليست في القتال، بل في حماية من تحب",
        character: "إيرين ييغر",
        anime: "Attack on Titan"
      },
      {
        text: "الخوف ليس شيئاً سيئاً، إنه يجعلك أقوى",
        character: "تانجيرو كامادو",
        anime: "Demon Slayer"
      },
      {
        text: "لا تستسلم أبداً، لأن الغد قد يكون أفضل من اليوم",
        character: "غوكو",
        anime: "Dragon Ball"
      },
      {
        text: "الصداقة الحقيقية تتجاوز كل الحدود",
        character: "ناتسو دراغنيل",
        anime: "Fairy Tail"
      },
      {
        text: "أحياناً أصعب المعارك هي التي نخوضها ضد أنفسنا",
        character: "إيتشيغو كوروساكي",
        anime: "Bleach"
      },
      {
        text: "الذكريات الجميلة تستحق كل الألم",
        character: "إدوارد إلريك",
        anime: "Fullmetal Alchemist"
      }
    ];

    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    
    return `✨ *اقتباس من عالم الأنمي* ✨\n\n💬 "${randomQuote.text}"\n\n👤 *القائل:* ${randomQuote.character}\n🎌 *من أنمي:* ${randomQuote.anime}\n\n🐱💫 مستر مياو بيجيبلك أحلى الاقتباسات!`;
  }
};
