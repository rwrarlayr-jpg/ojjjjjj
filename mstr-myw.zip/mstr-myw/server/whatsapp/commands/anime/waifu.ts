import { Command } from '../index';

export const waifuCommand: Command = {
  name: 'وايفو',
  description: 'صور شخصيات الوايفو',
  category: 'anime',
  adminOnly: false,
  execute: async ({ args }) => {
    const waifuName = args.join(' ').toLowerCase();
    
    // Popular waifu database
    const waifuDatabase: Record<string, {
      name: string;
      anime: string;
      description: string;
      image: string;
    }> = {
      'زيرو تو': {
        name: 'Zero Two',
        anime: 'Darling in the FranXX',
        description: 'الأونتي الوردية اللي خلت كل الأوتاكو يحبوها! 💖',
        image: 'https://cdn.myanimelist.net/images/characters/9/350563.jpg'
      },
      'ميكاسا': {
        name: 'Mikasa Ackerman',
        anime: 'Attack on Titan',
        description: 'المحاربة القوية اللي تحمي إيرين بكل قوتها! ⚔️',
        image: 'https://cdn.myanimelist.net/images/characters/9/215563.jpg'
      },
      'هينتا': {
        name: 'Hinata Hyuga',
        anime: 'Naruto',
        description: 'الأميرة الخجولة اللي حبت ناروتو من زمان! 💜',
        image: 'https://cdn.myanimelist.net/images/characters/5/374495.jpg'
      },
      'نامي': {
        name: 'Nami',
        anime: 'One Piece',
        description: 'ملكة جمال القراصنة ومحبة الكنوز! 💰',
        image: 'https://cdn.myanimelist.net/images/characters/5/253569.jpg'
      }
    };

    if (waifuName && waifuDatabase[waifuName]) {
      const waifu = waifuDatabase[waifuName];
      
      return {
        type: 'image',
        url: waifu.image,
        caption: `💖 *${waifu.name}* 💖\n\n🎌 من أنمي: ${waifu.anime}\n✨ ${waifu.description}\n\n🐱💕 مستر مياو فاهم الأذواق الرفيعة!`
      };
    } else if (waifuName) {
      return `🔍 *بحث عن وايفو: ${args.join(' ')}*\n\n😅 آسف يا حبيبي، ما لقيتش الوايفو دي\n\n💝 *الوايفو المتاحة:*\n• زيرو تو\n• ميكاسا\n• هينتا\n• نامي\n\n🐱💖 اختار واحدة وهجيبلك أحلى صورها!`;
    } else {
      // Random waifu
      const waifuList = Object.values(waifuDatabase);
      const randomWaifu = waifuList[Math.floor(Math.random() * waifuList.length)];
      
      return {
        type: 'image',
        url: randomWaifu.image,
        caption: `🎲 *وايفو عشوائية!* 🎲\n\n💖 *${randomWaifu.name}*\n🎌 من أنمي: ${randomWaifu.anime}\n✨ ${randomWaifu.description}\n\n🐱💕 مفاجأة من مستر مياو!`
      };
    }
  }
};
