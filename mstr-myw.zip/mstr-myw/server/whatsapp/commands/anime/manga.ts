import { Command } from '../index';

export const mangaCommand: Command = {
  name: 'مانجا',
  description: 'بحث في المانجا',
  category: 'anime',
  adminOnly: false,
  execute: async ({ args }) => {
    if (args.length === 0) {
      return `📚 *مكتبة المانجا - مستر مياو* 📚\n\n📝 *الاستخدام:*\n.مانجا [اسم المانجا]\n\n💡 *أمثلة:*\n• .مانجا ناروتو\n• .مانجا بيرسيرك\n• .مانجا جوجوتسو كايسن\n\n🐱📖 اكتب اسم مانجا وهجيبلك معلومات عنها!`;
    }

    const mangaName = args.join(' ').toLowerCase();
    
    const mangaDatabase: Record<string, {
      name: string;
      author: string;
      chapters: string;
      status: string;
      description: string;
      rating: string;
      image: string;
    }> = {
      'ناروتو': {
        name: 'Naruto',
        author: 'Masashi Kishimoto',
        chapters: '700 فصل',
        status: 'مكتملة',
        description: 'قصة نينجا صغير بيحارب عشان يحقق حلمه',
        rating: '⭐⭐⭐⭐⭐',
        image: 'https://cdn.myanimelist.net/images/manga/3/117681.jpg'
      },
      'بيرسيرك': {
        name: 'Berserk',
        author: 'Kentaro Miura',
        chapters: '364+ فصل',
        status: 'مستمرة',
        description: 'ملحمة الفارس الأسود جاتس في عالم مظلم',
        rating: '⭐⭐⭐⭐⭐',
        image: 'https://cdn.myanimelist.net/images/manga/1/157931.jpg'
      },
      'جوجوتسو كايسن': {
        name: 'Jujutsu Kaisen',
        author: 'Gege Akutami',
        chapters: '200+ فصل',
        status: 'مستمرة',
        description: 'محاربة اللعنات والأرواح الشريرة',
        rating: '⭐⭐⭐⭐⭐',
        image: 'https://cdn.myanimelist.net/images/manga/3/210341.jpg'
      }
    };

    const manga = mangaDatabase[mangaName] || 
                  Object.values(mangaDatabase).find(m => 
                    m.name.toLowerCase().includes(mangaName) ||
                    mangaName.includes(m.name.toLowerCase())
                  );

    if (manga) {
      return {
        type: 'image',
        url: manga.image,
        caption: `📚 *${manga.name}* 📚\n\n✍️ المؤلف: ${manga.author}\n📖 عدد الفصول: ${manga.chapters}\n📊 الحالة: ${manga.status}\n${manga.rating}\n\n📝 *القصة:*\n${manga.description}\n\n🐱📚 استمتع بالقراءة يا حبيبي!`
      };
    } else {
      return `🔍 *نتائج البحث عن: ${args.join(' ')}*\n\n😅 آسف يا حبيبي، ما لقيتش المانجا دي\n\n📚 *المانجا المتاحة:*\n• ناروتو\n• بيرسيرك\n• جوجوتسو كايسن\n• ون بيس\n• اتاك اون تايتن\n\n🐱📖 جرب تدور بأسماء تانية!`;
    }
  }
};
