import { Command } from '../index';

export const kawaiiCommand: Command = {
  name: 'كاواي',
  description: 'صور كاواي ولطيفة',
  category: 'anime',
  adminOnly: false,
  execute: async () => {
    const kawaiiImages = [
      {
        url: 'https://cdn.nekos.life/neko/neko_001.jpg',
        caption: '🐱 نيكو كاواي! مياو مياو~ 💕'
      },
      {
        url: 'https://cdn.nekos.life/neko/neko_002.jpg',
        caption: '✨ كاواي ديسو نيه! اللطافة في أبهى صورها! 🌸'
      },
      {
        url: 'https://cdn.nekos.life/neko/neko_003.jpg',
        caption: '💖 أوني-تشان، هذا لطيف جداً! 😍'
      },
      {
        url: 'https://cdn.nekos.life/neko/neko_004.jpg',
        caption: '🎀 مو، مو، كيوت! قلبي ذاب من اللطافة! 💘'
      },
      {
        url: 'https://cdn.nekos.life/neko/neko_005.jpg',
        caption: '🌺 كاواي! هذا أحلى من الساكورا! 🌸'
      }
    ];

    const randomImage = kawaiiImages[Math.floor(Math.random() * kawaiiImages.length)];
    
    return {
      type: 'image',
      url: randomImage.url,
      caption: `${randomImage.caption}\n\n🐱💕 مستر مياو جابلك جرعة كاواي تخليك تطير من الفرحة!\n\n✨ *Kawaii desu ne~* ✨`
    };
  }
};
