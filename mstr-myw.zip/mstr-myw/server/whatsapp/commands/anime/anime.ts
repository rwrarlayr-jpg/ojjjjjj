import { Command } from '../index';
import { getRandomResponse } from '../../utils/responses';

export const animeCommand: Command = {
  name: 'انمي',
  description: 'بحث عن أنمي معين',
  category: 'anime',
  adminOnly: false,
  execute: async ({ args }) => {
    if (args.length === 0) {
      return `🎌 *بحث الأنمي - مستر مياو* 🎌\n\n📝 *الاستخدام:*\n.انمي [اسم الأنمي]\n\n💡 *أمثلة:*\n• .انمي ناروتو\n• .انمي ون بيس\n• .انمي دراغون بول\n\n🐱⚡ اكتب اسم أنمي وهجيبلك كل حاجة عنه!`;
    }

    const animeName = args.join(' ');
    
    // Simulate anime search with popular anime
    const animeDatabase: Record<string, {
      name: string;
      description: string;
      episodes: string;
      rating: string;
      image: string;
    }> = {
      'ناروتو': {
        name: 'ناروتو',
        description: 'قصة نينجا صغير بيحلم يبقى هوكاجي القرية',
        episodes: '720 حلقة',
        rating: '⭐⭐⭐⭐⭐',
        image: 'https://cdn.myanimelist.net/images/anime/13/17405.jpg'
      },
      'ون بيس': {
        name: 'ون بيس',
        description: 'مغامرات لوفي وطاقمه للبحث عن الكنز الأسطوري',
        episodes: '1000+ حلقة',
        rating: '⭐⭐⭐⭐⭐',
        image: 'https://cdn.myanimelist.net/images/anime/6/73245.jpg'
      },
      'اتاك اون تايتن': {
        name: 'هجوم العمالقة',
        description: 'البشر يحاربوا العمالقة عشان البقاء',
        episodes: '87 حلقة',
        rating: '⭐⭐⭐⭐⭐',
        image: 'https://cdn.myanimelist.net/images/anime/10/47347.jpg'
      }
    };

    const anime = animeDatabase[animeName.toLowerCase()] || 
                  Object.values(animeDatabase).find(a => 
                    a.name.toLowerCase().includes(animeName.toLowerCase())
                  );

    if (anime) {
      const response = getRandomResponse('anime', { anime: anime.name });
      
      return {
        type: 'image',
        url: anime.image,
        caption: `${response}\n\n📺 *${anime.name}*\n📖 ${anime.description}\n🎬 عدد الحلقات: ${anime.episodes}\n${anime.rating}\n\n🐱🎌 استمتع بالمشاهدة!`
      };
    } else {
      return `🔍 *نتائج البحث عن: ${animeName}*\n\n😅 آسف يا حبيبي، ما لقيتش الأنمي ده في قاعدة البيانات\n\n💡 *جرب تدور على:*\n• ناروتو\n• ون بيس\n• اتاك اون تايتن\n• دراغون بول\n• ديث نوت\n\n🐱⚡ أو ابعتلي اسم أنمي تاني!`;
    }
  }
};
