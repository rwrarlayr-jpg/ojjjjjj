import { Command } from '../index';

export const luckCommand: Command = {
  name: 'حظ',
  description: 'ألعاب الحظ والتوقعات',
  category: 'challenges',
  adminOnly: false,
  execute: async ({ args }) => {
    const luckType = args[0]?.toLowerCase();
    
    if (!luckType || !['نرد', 'عملة', 'بخت', 'توقع', 'dice', 'coin', 'fortune', 'predict'].includes(luckType)) {
      return `🎲 *ألعاب الحظ - مستر مياو* 🎲\n\n🎯 *الألعاب المتاحة:*\n• .حظ نرد - رمي النرد\n• .حظ عملة - رمي العملة\n• .حظ بخت - قراءة البخت\n• .حظ توقع - توقعات اليوم\n\n🐱🍀 اختار لعبة وشوف حظك إيه النهاردة!`;
    }
    
    if (luckType === 'نرد' || luckType === 'dice') {
      const diceRoll = Math.floor(Math.random() * 6) + 1;
      const messages = [
        '🎲 واااو! نتيجة ممتازة!',
        '🎲 مش بطالة، كده كويس!',
        '🎲 حظ عادي، ممكن أحسن!',
        '🎲 أوووه! تعبان شوية!',
        '🎲 ماشي الحال كده!',
        '🎲 نتيجة رائعة جداً!'
      ];
      
      return `🎲 *رمي النرد!* 🎲\n\n🎯 *النتيجة:* ${diceRoll}\n\n${messages[diceRoll - 1]}\n\n🐱🎲 مستر مياو رمالك النرد!`;
    }
    
    if (luckType === 'عملة' || luckType === 'coin') {
      const coinFlip = Math.random() < 0.5 ? 'صورة' : 'كتابة';
      const emoji = coinFlip === 'صورة' ? '👑' : '📝';
      
      return `🪙 *رمي العملة!* 🪙\n\n${emoji} *النتيجة:* ${coinFlip}\n\n🐱🪙 مستر مياو رمالك العملة!`;
    }
    
    if (luckType === 'بخت' || luckType === 'fortune') {
      const fortunes = [
        '🌟 بختك اليوم ممتاز! توقع أخبار سعيدة!',
        '💫 يوم جميل ينتظرك، استمتع بكل لحظة!',
        '⭐ حظك اليوم في الحب والعمل رائع!',
        '🍀 اليوم يوم الفرص الذهبية، لا تفوتها!',
        '✨ طاقة إيجابية كبيرة تحيط بك اليوم!',
        '🌈 بعد العاصفة يأتي قوس قزح، اصبر!',
        '🎯 ركز على أهدافك اليوم، النجاح قريب!',
        '💎 أنت كالماس، تتألق تحت الضغط!',
        '🦋 تغيير جميل قادم في حياتك قريباً!',
        '🌸 الحب والسعادة في طريقهما إليك!'
      ];
      
      const randomFortune = fortunes[Math.floor(Math.random() * fortunes.length)];
      
      return `🔮 *قراءة البخت!* 🔮\n\n${randomFortune}\n\n🐱🔮 مستر مياو شاف مستقبلك في الكريستالة!`;
    }
    
    if (luckType === 'توقع' || luckType === 'predict') {
      const predictions = [
        '📱 هتاخد رسالة مهمة النهاردة!',
        '😊 هتقابل صديق قديم قريباً!',
        '💰 فرصة مالية ممتازة في طريقها ليك!',
        '❤️ الحب هيدق بابك قريب أوي!',
        '🎉 مناسبة سعيدة هتحصل الأسبوع ده!',
        '📚 هتتعلم حاجة جديدة ومفيدة!',
        '🌟 هتكون نجم اليوم في شغلك!',
        '🎁 مفاجأة حلوة مستنياك!',
        '🏆 هتحقق إنجاز كبير قريباً!',
        '🌅 يوم جديد، فرص جديدة، أمل جديد!'
      ];
      
      const randomPrediction = predictions[Math.floor(Math.random() * predictions.length)];
      
      return `🌟 *توقعات اليوم!* 🌟\n\n${randomPrediction}\n\n🐱⚡ مستر مياو بيقولك المستقبل!`;
    }
  }
};
