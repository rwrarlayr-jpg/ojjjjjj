import { Command } from '../index';

export const competitionCommand: Command = {
  name: 'مسابقة',
  description: 'مسابقات جماعية',
  category: 'challenges',
  adminOnly: false,
  execute: async ({ isGroup }) => {
    if (!isGroup) {
      return '🚫 المسابقات للمجموعات بس يا حبيبي!\nادخل مجموعة وجرب تاني 🐱🏆';
    }

    const competitions = [
      {
        title: 'مسابقة الأنمي الثقافية',
        description: 'أسئلة عن شخصيات وقصص الأنمي المشهورة',
        questions: [
          'مين أول هوكاجي في قرية الورق؟',
          'إيه اسم السيف بتاع زورو في ون بيس؟',
          'كام عملاق أساسي في اتاك اون تايتن؟'
        ],
        duration: '10 دقائق',
        prize: '🏆 لقب أوتاكو المجموعة'
      },
      {
        title: 'تحدي السرعة',
        description: 'أول واحد يجاوب على السؤال يكسب',
        questions: [
          'إيه لون شعر ناروتو؟',
          'مين بطل أنمي ديث نوت؟',
          'إيه اسم أنمي الولد اللي بيقتل الشياطين؟'
        ],
        duration: '5 دقائق',
        prize: '⚡ لقب البرق السريع'
      },
      {
        title: 'مسابقة الذاكرة',
        description: 'اذكر أكبر عدد من شخصيات الأنمي',
        questions: [
          'اذكر 10 شخصيات من ناروتو',
          'اذكر 5 أنميات مشهورة',
          'اذكر أسماء أعضاء طاقم لوفي'
        ],
        duration: '15 دقيقة',
        prize: '🧠 لقب عبقري الأنمي'
      }
    ];

    const randomCompetition = competitions[Math.floor(Math.random() * competitions.length)];
    
    return `🏆 *مسابقة جماعية!* 🏆\n\n🎯 *${randomCompetition.title}*\n\n📝 *الوصف:*\n${randomCompetition.description}\n\n⏰ *المدة:* ${randomCompetition.duration}\n🎁 *الجائزة:* ${randomCompetition.prize}\n\n🚀 *بدء المسابقة خلال 30 ثانية!*\nاستعدوا يا أوتاكو! 🐱⚡\n\n💡 *ملاحظة:* اكتبوا إجاباتكم في الشات وأول إجابة صحيحة تكسب!`;
  }
};
