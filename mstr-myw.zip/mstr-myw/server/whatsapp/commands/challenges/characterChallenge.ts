import { Command } from '../index';

export const characterChallengeCommand: Command = {
  name: 'تحدي_شخصية',
  description: 'تخمين شخصية الأنمي',
  category: 'challenges',
  adminOnly: false,
  execute: async () => {
    const characters = [
      {
        name: 'ناروتو أوزوماكي',
        anime: 'Naruto',
        hint: 'نينجا أشقر بيحب الرامن ويحلم يبقى هوكاجي',
        image: 'https://cdn.myanimelist.net/images/characters/2/284121.jpg'
      },
      {
        name: 'مونكي دي لوفي',
        anime: 'One Piece',
        hint: 'قبطان قراصنة جسمه مطاطي وبيحب اللحمة',
        image: 'https://cdn.myanimelist.net/images/characters/9/310307.jpg'
      },
      {
        name: 'غوكو',
        anime: 'Dragon Ball',
        hint: 'محارب سايان قوي جداً وبيحب القتال والأكل',
        image: 'https://cdn.myanimelist.net/images/characters/7/284129.jpg'
      },
      {
        name: 'إيرين ييغر',
        anime: 'Attack on Titan',
        hint: 'عايز ينتقم من العمالقة اللي دمروا قريته',
        image: 'https://cdn.myanimelist.net/images/characters/10/216895.jpg'
      },
      {
        name: 'إيتشيغو كوروساكي',
        anime: 'Bleach',
        hint: 'طالب ثانوية بقى حاصد أرواح عشان يحمي أصحابه',
        image: 'https://cdn.myanimelist.net/images/characters/3/285534.jpg'
      }
    ];

    const randomCharacter = characters[Math.floor(Math.random() * characters.length)];
    
    return {
      type: 'image',
      url: randomCharacter.image,
      caption: `🎭 *تحدي الشخصية!* 🎭\n\n🔍 *الدليل:*\n${randomCharacter.hint}\n\n❓ مين الشخصية دي؟\n⚡ اكتب .جواب [اسم الشخصية]\n⏰ عندك دقيقة واحدة!\n\n🐱🏆 يلا شوف لو انت فاهم في الأنمي ولا لأ!`
    };
  }
};
