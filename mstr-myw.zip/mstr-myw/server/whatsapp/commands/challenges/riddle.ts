import { Command } from '../index';

export const riddleCommand: Command = {
  name: 'احجية',
  description: 'أحاجي وألغاز',
  category: 'challenges',
  adminOnly: false,
  execute: async () => {
    const riddles = [
      {
        question: 'شيء له عينان ولا يرى، وله أذنان ولا يسمع، ما هو؟',
        answer: 'المقص',
        difficulty: 'سهل'
      },
      {
        question: 'ما الشيء الذي يكتب ولا يقرأ؟',
        answer: 'القلم',
        difficulty: 'سهل'
      },
      {
        question: 'شيء أبيض من الخارج، أخضر من الوسط، أحمر من الداخل، وفيه نقط سوداء؟',
        answer: 'البطيخ',
        difficulty: 'متوسط'
      },
      {
        question: 'ما الشيء الذي يمشي بلا أرجل، ويبكي بلا عينين؟',
        answer: 'السحاب',
        difficulty: 'متوسط'
      },
      {
        question: 'له رأس ولا يفكر، وله أسنان ولا يأكل؟',
        answer: 'الثوم',
        difficulty: 'صعب'
      },
      {
        question: 'كلما زاد نقص، وكلما نقص زاد؟',
        answer: 'العمر',
        difficulty: 'صعب'
      },
      {
        question: 'ما الشيء الذي إذا أكلته كله تستفيد، وإذا أكلت نصفه تموت؟',
        answer: 'السمسم',
        difficulty: 'صعب'
      },
      {
        question: 'شيء موجود في كل البيوت، إذا ذكرت اسمه كسرته؟',
        answer: 'الصمت',
        difficulty: 'متوسط'
      }
    ];

    const randomRiddle = riddles[Math.floor(Math.random() * riddles.length)];
    
    return `🧩 *أحجية مستر مياو!* 🧩\n\n❓ *السؤال:*\n${randomRiddle.question}\n\n🎯 *المستوى:* ${randomRiddle.difficulty}\n⚡ *للإجابة:* اكتب .جواب [إجابتك]\n⏰ عندك دقيقتين للتفكير!\n\n🐱💭 فكر كويس يا ذكي، الجواب قدامك!`;
  }
};
