import { Command } from '../index';
import { getRandomResponse } from '../../utils/responses';

// Store active challenges per user
const activeChallenges: Map<string, { challengeId: string; answer: string; points: number; startTime: number }> = new Map();

export const eyeChallengeCommand: Command = {
  name: 'تحدي_عين',
  description: 'تحدي تخمين لون العين بمستويات صعوبة',
  category: 'challenges',
  adminOnly: false,
  execute: async ({ storage, sender }) => {
    try {
      const challenge = await storage.getRandomChallenge('eye');
      
      if (!challenge) {
        return '😅 آسف يا حبيبي، مافيش تحديات عيون متاحة دلوقتي\nجرب تاني كمان شوية! 🐱👁️';
      }

      // Store the challenge for this user
      activeChallenges.set(sender, {
        challengeId: challenge.id,
        answer: challenge.answer.toLowerCase().trim(),
        points: challenge.points || 10,
        startTime: Date.now()
      });

      const challengeText = getRandomResponse('challenges');
      const difficultyEmoji = challenge.difficulty === 'hard' ? '🔥' : challenge.difficulty === 'medium' ? '⚡' : '✨';
      
      if (challenge.imageUrl) {
        return {
          type: 'image',
          url: challenge.imageUrl,
          caption: `${challengeText}\n\n🎯 *تحدي العين!* ${difficultyEmoji}\n\n👁️ شوف الصورة دي كويس وقولي إيه لون العين\n💎 النقاط: ${challenge.points}\n⏰ عندك 30 ثانية بس!\n⚡ الجواب الصحيح: اكتب .جواب [لون العين]\n\n🐱🏆 يلا ورينا مهاراتك في الملاحظة!`
        };
      } else {
        return `👁️ *تحدي العين!* 👁️ ${difficultyEmoji}\n\n${challenge.question}\n\n💎 النقاط: ${challenge.points}\n⏰ عندك 30 ثانية للإجابة!\n⚡ اكتب .جواب [إجابتك]\n\n🐱🎯 يلا فكر كويس!`;
      }
      
    } catch (error) {
      console.error('Error in eye challenge:', error);
      return '😞 آسف، حصل خطأ في تحدي العين\nجرب تاني كمان شوية 🐱💔';
    }
  }
};

export const answerCommand: Command = {
  name: 'جواب',
  description: 'الإجابة على التحديات',
  category: 'challenges',
  adminOnly: false,
  execute: async ({ args, sender, storage }) => {
    if (!args.length) {
      return '📝 لازم تكتب إجابتك!\nمثال: .جواب أزرق 🐱💭';
    }

    const activeChallenge = activeChallenges.get(sender);
    
    if (!activeChallenge) {
      return '❌ مافيش تحدي نشط!\nاكتب .تحدي_عين عشان تبدأ تحدي جديد 🐱🎮';
    }

    const userAnswer = args.join(' ').toLowerCase().trim();
    const timeTaken = Date.now() - activeChallenge.startTime;
    
    // Check if timeout (30 seconds)
    if (timeTaken > 30000) {
      activeChallenges.delete(sender);
      return `⏰ *انتهى الوقت!* ⏰\n\n😔 الوقت المسموح 30 ثانية بس\n✅ الإجابة الصحيحة كانت: ${activeChallenge.answer}\n\n🐱 جرب تاني وكن أسرع!`;
    }

    // Check answer
    if (userAnswer === activeChallenge.answer || userAnswer.includes(activeChallenge.answer)) {
      activeChallenges.delete(sender);
      
      // Calculate bonus for speed
      let points = activeChallenge.points;
      let speedBonus = 0;
      if (timeTaken < 10000) {
        speedBonus = 5;
        points += speedBonus;
      }
      
      // Update user points
      const userPoints = await storage.updateUserPoints(sender, points, 1);
      
      return `🎉 *صح! إجابة ممتازة!* 🎉\n\n✨ أحسنت يا بطل!\n💎 النقاط المكتسبة: ${points} نقطة${speedBonus > 0 ? ` (+${speedBonus} بونص سرعة⚡)` : ''}\n📊 مجموع نقاطك: ${userPoints.points}\n🏆 رتبتك: ${userPoints.rank}\n⏱️ الوقت: ${(timeTaken / 1000).toFixed(1)} ثانية\n\n🐱⭐ عاش يا فنان! استمر!`;
    } else {
      activeChallenges.delete(sender);
      return `❌ *للأسف إجابة خاطئة!* ❌\n\n💔 إجابتك: ${userAnswer}\n✅ الإجابة الصحيحة: ${activeChallenge.answer}\n\n🐱 المرة الجاية هتعملها! جرب تاني!`;
    }
  }
};
