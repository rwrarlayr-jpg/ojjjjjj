import { Command } from '../index';

export const prayerTimesCommand: Command = {
  name: 'مواقيت_الصلاة',
  description: 'مواقيت الصلاة اليومية',
  category: 'religious',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const city = args.join(' ') || 'القاهرة';
    
    // Mock prayer times (in real implementation, use prayer times API)
    const prayerTimes = {
      'الفجر': '04:30',
      'الشروق': '06:15',
      'الظهر': '12:45',
      'العصر': '16:20',
      'المغرب': '19:35',
      'العشاء': '21:10'
    };
    
    const today = new Date().toLocaleDateString('ar-EG');
    
    let message = `🕌 *مواقيت الصلاة* 🕌\n\n📅 التاريخ: ${today}\n🏙️ المدينة: ${city}\n\n`;
    
    Object.entries(prayerTimes).forEach(([prayer, time]) => {
      const prayerEmojis: Record<string, string> = {
        'الفجر': '🌅',
        'الشروق': '☀️',
        'الظهر': '🌞',
        'العصر': '🌇',
        'المغرب': '🌆',
        'العشاء': '🌙'
      };
      
      message += `${prayerEmojis[prayer]} ${prayer}: ${time}\n`;
    });
    
    message += '\n🐱📿 مستر مياو يذكرك بالصلاة!';
    
    return message;
  }
};

export const quranCommand: Command = {
  name: 'قرآن',
  description: 'آيات من القرآن الكريم',
  category: 'religious',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const surahNumber = parseInt(args[0]) || null;
    
    const verses = [
      {
        text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
        surah: 'الفاتحة',
        ayah: 1
      },
      {
        text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
        surah: 'الفاتحة',
        ayah: 2
      },
      {
        text: 'الرَّحْمَٰنِ الرَّحِيمِ',
        surah: 'الفاتحة',
        ayah: 3
      },
      {
        text: 'وَاللَّهُ أَعْلَمُ بِأَعْدَائِكُمْ ۚ وَكَفَىٰ بِاللَّهِ وَلِيًّا وَكَفَىٰ بِاللَّهِ نَصِيرًا',
        surah: 'النساء',
        ayah: 45
      }
    ];
    
    const randomVerse = verses[Math.floor(Math.random() * verses.length)];
    
    return `📖 *من القرآن الكريم* 📖\n\n"${randomVerse.text}"\n\n📍 سورة ${randomVerse.surah} - آية ${randomVerse.ayah}\n\n🐱📿 مستر مياو يقرأ معك القرآن`;
  }
};

export const hadithCommand: Command = {
  name: 'حديث',
  description: 'أحاديث نبوية شريفة',
  category: 'religious',
  adminOnly: false,
  execute: async () => {
    const hadiths = [
      {
        text: 'إنما الأعمال بالنيات وإنما لكل امرئ ما نوى',
        narrator: 'عمر بن الخطاب',
        source: 'البخاري ومسلم'
      },
      {
        text: 'من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت',
        narrator: 'أبو هريرة',
        source: 'البخاري ومسلم'
      },
      {
        text: 'المؤمن للمؤمن كالبنيان يشد بعضه بعضاً',
        narrator: 'أبو موسى الأشعري',
        source: 'البخاري ومسلم'
      },
      {
        text: 'لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه',
        narrator: 'أنس بن مالك',
        source: 'البخاري ومسلم'
      }
    ];
    
    const randomHadith = hadiths[Math.floor(Math.random() * hadiths.length)];
    
    return `🌟 *حديث شريف* 🌟\n\nقال رسول الله ﷺ:\n"${randomHadith.text}"\n\n📚 رواه: ${randomHadith.narrator}\n📖 المصدر: ${randomHadith.source}\n\n🐱📿 مستر مياو يشارك السنة النبوية`;
  }
};

export const dhikrCommand: Command = {
  name: 'أذكار',
  description: 'أذكار يومية',
  category: 'religious',
  adminOnly: false,
  execute: async ({ args }: any) => {
    const type = args[0]?.toLowerCase() || 'عامة';
    
    const adhkar = {
      'صباح': [
        'أصبحنا وأصبح الملك لله رب العالمين',
        'اللهم أنت ربي لا إله إلا أنت خلقتني وأنا عبدك',
        'اللهم أصبحت منك في نعمة وعافية وستر'
      ],
      'مساء': [
        'أمسينا وأمسى الملك لله رب العالمين',
        'اللهم أمسيت منك في نعمة وعافية وستر',
        'أمسينا على فطرة الإسلام وكلمة الإخلاص'
      ],
      'عامة': [
        'سبحان الله وبحمده سبحان الله العظيم',
        'لا إله إلا الله وحده لا شريك له',
        'الحمد لله رب العالمين',
        'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه'
      ]
    };
    
    const typeAdhkar = adhkar[type as keyof typeof adhkar] || adhkar['عامة'];
    const randomDhikr = typeAdhkar[Math.floor(Math.random() * typeAdhkar.length)];
    
    return `🤲 *أذكار ${type}* 🤲\n\n"${randomDhikr}"\n\n🐱📿 مستر مياو يذكر الله معك\n\nالأنواع: صباح، مساء، عامة`;
  }
};

export const islamicFactCommand: Command = {
  name: 'معلومة_دينية',
  description: 'معلومات إسلامية مفيدة',
  category: 'religious',
  adminOnly: false,
  execute: async () => {
    const facts = [
      '📚 القرآن الكريم يحتوي على 114 سورة و 6236 آية',
      '🕌 أول مسجد بُني في الإسلام هو مسجد قباء في المدينة المنورة',
      '📅 الشهر الفضيل رمضان هو الشهر التاسع في التقويم الهجري',
      '🏔️ جبل النور في مكة المكرمة يحتوي على غار حراء حيث نزل الوحي',
      '⭐ خديجة بنت خويلد رضي الله عنها كانت أول من آمن برسالة النبي ﷺ',
      '🌙 العام الهجري يبدأ بشهر محرم وهو من الأشهر الحرم'
    ];
    
    const randomFact = facts[Math.floor(Math.random() * facts.length)];
    
    return `💡 *معلومة دينية* 💡\n\n${randomFact}\n\n🐱📚 مستر مياو يعلمك الدين`;
  }
};