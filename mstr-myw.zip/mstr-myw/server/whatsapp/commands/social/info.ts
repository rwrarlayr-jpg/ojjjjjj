import { Command } from '../index';

export const whoAmICommand: Command = {
  name: 'من_انا',
  description: 'معلومات عن المستخدم',
  category: 'social',
  adminOnly: false,
  execute: async ({ message }: any) => {
    const sender = message?.key?.remoteJid?.includes('@g.us') 
      ? message?.key?.participant 
      : message?.key?.remoteJid;
    
    const userNumber = sender?.replace('@s.whatsapp.net', '') || 'غير معروف';
    const userName = message?.pushName || 'مستخدم';
    
    return `👤 *معلوماتك* 👤\n\n📱 الرقم: ${userNumber}\n🏷️ الاسم: ${userName}\n📅 تاريخ الانضمام: جديد\n⭐ المستوى: مستخدم عادي\n\n🐱💫 مرحباً بك في عالم مستر مياو!`;
  }
};

export const groupInfoCommand: Command = {
  name: 'معلومات_المجموعة',
  description: 'معلومات عن المجموعة',
  category: 'social',
  adminOnly: false,
  execute: async ({ message }: any) => {
    const isGroup = message?.key?.remoteJid?.includes('@g.us');
    
    if (!isGroup) {
      return '❌ هذا الأمر يعمل في المجموعات فقط!';
    }
    
    const groupId = message?.key?.remoteJid || '';
    const groupName = 'مجموعة واتساب'; // In real implementation, get from group metadata
    
    return `👥 *معلومات المجموعة* 👥\n\n🏷️ الاسم: ${groupName}\n🆔 المعرف: ${groupId}\n👥 الأعضاء: يتم التحديث...\n📅 تاريخ الإنشاء: غير متاح\n🔒 النوع: عامة\n\n🐱👥 مستر مياو يراقب المجموعة!`;
  }
};

export const profileCommand: Command = {
  name: 'الملف_الشخصي',
  description: 'عرض الملف الشخصي',
  category: 'social',
  adminOnly: false,
  execute: async ({ message, args }: any) => {
    const targetUser = args[0]; // mention or number
    const currentUser = message?.key?.remoteJid?.replace('@s.whatsapp.net', '') || 'غير معروف';
    
    const user = targetUser || currentUser;
    const stats = {
      commandsUsed: Math.floor(Math.random() * 100) + 1,
      joinDate: '2024-01-01',
      level: Math.floor(Math.random() * 20) + 1,
      points: Math.floor(Math.random() * 1000) + 100
    };
    
    return `👤 *الملف الشخصي* 👤\n\n📱 المستخدم: ${user}\n⭐ المستوى: ${stats.level}\n🏆 النقاط: ${stats.points}\n📊 الأوامر المستخدمة: ${stats.commandsUsed}\n📅 تاريخ الانضمام: ${stats.joinDate}\n\n🐱📋 ملف محفوظ بعناية مستر مياو!`;
  }
};

export const topUsersCommand: Command = {
  name: 'المتصدرين',
  description: 'قائمة أكثر المستخدمين نشاطاً',
  category: 'social',
  adminOnly: false,
  execute: async () => {
    const topUsers = [
      { name: 'أحمد المحترف', points: 1250, commands: 89 },
      { name: 'فاطمة النشطة', points: 1100, commands: 76 },
      { name: 'محمد اللاعب', points: 950, commands: 62 },
      { name: 'سارة المبدعة', points: 800, commands: 54 },
      { name: 'خالد السريع', points: 750, commands: 48 }
    ];
    
    let leaderboardMessage = '🏆 *المتصدرين* 🏆\n\n';
    const medals = ['🥇', '🥈', '🥉', '🏅', '🎖️'];
    
    topUsers.forEach((user, index) => {
      leaderboardMessage += `${medals[index] || '🏅'} ${user.name}\n`;
      leaderboardMessage += `   💎 النقاط: ${user.points}\n`;
      leaderboardMessage += `   📊 الأوامر: ${user.commands}\n\n`;
    });
    
    leaderboardMessage += '🐱🏆 تصنيف مستر مياو الأسبوعي!';
    
    return leaderboardMessage;
  }
};

export const statsCommand: Command = {
  name: 'احصائيات',
  description: 'إحصائيات البوت والمجموعة',
  category: 'social',
  adminOnly: false,
  execute: async ({ message }: any) => {
    const isGroup = message?.key?.remoteJid?.includes('@g.us');
    
    const botStats = {
      totalCommands: 300,
      activeUsers: Math.floor(Math.random() * 100) + 50,
      commandsToday: Math.floor(Math.random() * 500) + 100,
      upTime: '5 أيام، 12 ساعة',
      groups: Math.floor(Math.random() * 20) + 5
    };
    
    let statsMessage = '📊 *إحصائيات مستر مياو* 📊\n\n';
    statsMessage += `🤖 إجمالي الأوامر: ${botStats.totalCommands}\n`;
    statsMessage += `👥 المستخدمين النشطين: ${botStats.activeUsers}\n`;
    statsMessage += `📈 أوامر اليوم: ${botStats.commandsToday}\n`;
    statsMessage += `⏰ وقت التشغيل: ${botStats.upTime}\n`;
    statsMessage += `🏘️ المجموعات: ${botStats.groups}\n\n`;
    
    if (isGroup) {
      const groupStats = {
        todayMessages: Math.floor(Math.random() * 200) + 50,
        activeMembers: Math.floor(Math.random() * 30) + 10,
        commandsUsed: Math.floor(Math.random() * 100) + 25
      };
      
      statsMessage += '👥 *إحصائيات المجموعة*\n';
      statsMessage += `💬 رسائل اليوم: ${groupStats.todayMessages}\n`;
      statsMessage += `🟢 الأعضاء النشطين: ${groupStats.activeMembers}\n`;
      statsMessage += `⚡ الأوامر المستخدمة: ${groupStats.commandsUsed}\n\n`;
    }
    
    statsMessage += '🐱📊 إحصائيات محدّثة من مستر مياو!';
    
    return statsMessage;
  }
};