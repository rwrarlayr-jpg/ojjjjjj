import { Command } from '../index';

export const rankCommand: Command = {
  name: 'رانك',
  description: 'معرفة رتبتك ونقاطك',
  category: 'social',
  adminOnly: false,
  execute: async ({ sender, storage }) => {
    const userPoints = await storage.getUserPoints(sender);
    
    if (!userPoints || userPoints.points === 0) {
      return '🌟 *أهلاً بيك يا بطل!* 🌟\n\n📊 نقاطك: 0\n🏆 رتبتك: مبتدئ\n🎯 التحديات المكتملة: 0\n\n💡 ابدأ التحديات عشان تكسب نقاط وترتقي في الرتب!\nاكتب .تحدي_عين عشان تبدأ 🐱⚡';
    }

    const topUsers = await storage.getTopUsers();
    const userRankPosition = topUsers.findIndex(u => u.phoneNumber === sender) + 1;
    
    return `🏆 *رتبتك ومعلوماتك* 🏆\n\n👤 الرقم: @${sender}\n💎 النقاط: ${userPoints.points}\n🎖️ الرتبة: ${userPoints.rank}\n🎯 التحديات المكتملة: ${userPoints.challengesCompleted}\n📊 ترتيبك: ${userRankPosition > 0 ? `#${userRankPosition}` : 'غير مصنف'}\n\n🐱⭐ استمر في التحديات عشان ترتقي أكتر!`;
  }
};

export const leaderboardCommand: Command = {
  name: 'المتصدرين',
  description: 'عرض لوحة المتصدرين',
  category: 'social',
  adminOnly: false,
  execute: async ({ storage }) => {
    const topUsers = await storage.getTopUsers(10);
    
    if (topUsers.length === 0) {
      return '📊 *لوحة المتصدرين* 📊\n\n😅 لسه ماحدش لعب!\nكن أول واحد يبدأ التحديات! 🐱🎮';
    }

    let leaderboard = '🏆 *أفضل 10 لاعبين* 🏆\n\n';
    
    topUsers.forEach((user, index) => {
      const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
      leaderboard += `${medal} @${user.phoneNumber}\n`;
      leaderboard += `   💎 ${user.points} نقطة | ${user.rank}\n\n`;
    });

    leaderboard += '🐱⚡ واصل مجهودك عشان توصل للقمة!';
    
    return leaderboard;
  }
};
