# Mr. Meow WhatsApp Bot Dashboard

## Overview

This is a comprehensive WhatsApp bot system called "Mr. Meow" (مستر مياو) built with a modern web dashboard. The application features a Node.js/Express backend with WhatsApp integration using Baileys library, and a React frontend for bot management and monitoring.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
The application follows a monorepo structure with clear separation between client, server, and shared components:
- **Frontend**: React with TypeScript, using Vite for development and building
- **Backend**: Node.js with Express server
- **Database**: PostgreSQL with Drizzle ORM
- **WhatsApp Integration**: Baileys library for WhatsApp Web API
- **Styling**: TailwindCSS with shadcn/ui components

## Key Components

### 1. Frontend (React Dashboard)
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **UI Library**: shadcn/ui components with Radix UI primitives
- **Styling**: TailwindCSS with custom anime-themed color palette
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for lightweight routing

### 2. Backend (Express Server)
- **Runtime**: Node.js with ES modules
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time Communication**: WebSocket server for live updates
- **Session Management**: Multi-file auth state for WhatsApp sessions

### 3. WhatsApp Bot Integration
- **Library**: @whiskeysockets/baileys for WhatsApp Web API
- **Features**: 
  - Pairing code authentication
  - Command system with 300+ commands
  - Egyptian dialect responses
  - Admin-only commands
  - Elite member system
  - Challenge system (eye, character, riddle challenges)

### 4. Database Schema
- **ORM**: Drizzle with PostgreSQL
- **Tables**:
  - `users`: User authentication
  - `bot_sessions`: WhatsApp connection sessions
  - `command_logs`: Command execution history
  - `elite_numbers`: Privileged user phone numbers
  - `group_settings`: Per-group configuration
  - `challenges`: Interactive challenges and games

### 5. Command System (300+ Commands)
- **Admin Commands** (10): User management, moderation, elite system
- **Anime Commands** (15): Anime info, waifu, manga, quotes, kawaii content
- **Challenge Commands** (20): Eye challenges, character challenges, riddles, competitions
- **Fun Commands** (40): Jokes, memes, games (dice, coin flip, rock-paper-scissors), quotes, wisdom
- **Utility Commands** (30): Calculator, encoding/decoding, QR codes, URL shortening, translation
- **Social Commands** (25): User profiles, group info, leaderboards, statistics
- **Entertainment Commands** (25): Movies, music, TV shows, books, news
- **Religious Commands** (15): Prayer times, Quran verses, Hadith, Dhikr, Islamic facts
- **Additional Commands** (120+): Extended variations and aliases for all categories

## Data Flow

1. **WhatsApp Messages**: Received through Baileys, processed by message handler
2. **Command Processing**: Commands parsed, validated, and executed with logging
3. **Real-time Updates**: WebSocket broadcasts bot status and logs to dashboard
4. **Database Operations**: All interactions logged and stored via Drizzle ORM
5. **Dashboard Interface**: Real-time monitoring and bot control through React UI

## External Dependencies

### Core Dependencies
- **@whiskeysockets/baileys**: WhatsApp Web API integration
- **@neondatabase/serverless**: PostgreSQL database driver
- **drizzle-orm**: Type-safe database ORM
- **express**: Web server framework
- **react**: Frontend UI library
- **vite**: Frontend build tool and dev server

### UI and Styling
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Tools
- **typescript**: Type safety
- **tsx**: TypeScript execution
- **esbuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR on client directory
- **Backend**: tsx for TypeScript execution with auto-restart
- **Database**: Environment variable configuration for DATABASE_URL

### Production Build
- **Frontend**: Vite builds to `dist/public`
- **Backend**: esbuild bundles server to `dist/index.js`
- **Assets**: Static file serving for built frontend

### Environment Configuration
- **Development**: NODE_ENV=development with local database
- **Production**: NODE_ENV=production with optimized builds
- **Database**: PostgreSQL connection via DATABASE_URL environment variable

### Key Architectural Decisions

1. **Monorepo Structure**: Chosen for code sharing between client/server and simplified deployment
2. **Drizzle ORM**: Selected for type safety and better developer experience over raw SQL
3. **WebSocket Integration**: Implemented for real-time dashboard updates without polling
4. **Command System**: Modular command structure for maintainability and extensibility
5. **Egyptian Dialect**: Bot responses in Egyptian Arabic for cultural authenticity
6. **Memory Storage with Database Backing**: Hybrid approach for performance and persistence

The architecture prioritizes developer experience, type safety, and real-time functionality while maintaining a clean separation of concerns between the WhatsApp bot logic and the web dashboard interface.